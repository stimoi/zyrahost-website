<?php
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "error" => "NOT_LOGGED"]);
    exit;
}

$user_id = $_SESSION['user_id'];

// ========= CONNEXION SQL =========
$db_host = 'localhost:3306';
$db_name = 'mttljx_zyrahostf_db';
$db_user = 'sti_moi';
$db_pass = 'pj32~lH36';

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8",
        $db_user,
        $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "error" => "DB_CONNECT",
        "details" => $e->getMessage()
    ]);
    exit;
}

// ========= LIMITE QUOTIDIENNE =========
$max_ads_per_day = 10;

$stmt = $pdo->prepare("
    SELECT COUNT(*) 
    FROM ad_logs 
    WHERE user_id = ? 
    AND DATE(created_at) = CURDATE()
");
$stmt->execute([$user_id]);
$ads_today = $stmt->fetchColumn();

if ($ads_today >= $max_ads_per_day) {
    echo json_encode(["success" => false, "error" => "LIMIT_REACHED"]);
    exit;
}

// ========= TOKEN ANTI-FRAUDE =========
$token = bin2hex(random_bytes(16));
$_SESSION['ad_token'] = $token;

// ========= REDIRECTION =========
$redirectUrl = "/coins_ad.php?token=" . $token;

echo json_encode([
    "success" => true,
    "redirect" => $redirectUrl
]);
?>
