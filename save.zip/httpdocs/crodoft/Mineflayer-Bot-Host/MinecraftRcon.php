<?php
class MinecraftRcon {
    private $socket;
    private $auth = false;
    private $request_id = 0;

    public function __construct($host, $port, $password) {
        $this->connect($host, $port);
        $this->auth($password);
    }

    private function connect($host, $port) {
        $this->socket = fsockopen($host, $port, $errno, $errstr, 3);
        if (!$this->socket) {
            throw new Exception("Impossible de se connecter: $errstr ($errno)");
        }
        stream_set_timeout($this->socket, 3, 0);
    }

    private function auth($password) {
        $this->sendPacket(3, $password);
        $response = $this->readPacket();
        $this->auth = $response['type'] == 2 && $response['request_id'] != -1;
        return $this->auth;
    }

    public function command($command) {
        if (!$this->auth) {
            throw new Exception("Non authentifié");
        }
        $this->sendPacket(2, $command);
        $response = $this->readPacket();
        return $response['payload'];
    }

    private function sendPacket($type, $payload) {
        $this->request_id++;
        $packet = pack('VV', $this->request_id, $type) . $payload . "\x00\x00";
        $packet = pack('V', strlen($packet)) . $packet;
        fwrite($this->socket, $packet, strlen($packet));
    }

    private function readPacket() {
        $size_data = fread($this->socket, 4);
        $size = unpack('V1size', $size_data)['size'];
        $packet = fread($this->socket, $size);
        $data = unpack('V1request_id/V1type/a*payload', $packet);
        $data['payload'] = substr($data['payload'], 0, -2); // Remove null bytes
        return $data;
    }

    public function __destruct() {
        if ($this->socket) {
            fclose($this->socket);
        }
    }
}
?>
