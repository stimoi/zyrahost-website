<?php
// Ce script est conçu pour être exécuté périodiquement pour mettre à jour le bot

// Vérifier si le bot est en cours d'exécution
if (!file_exists('bot.pid')) {
    exit(0);
}

$pid = trim(file_get_contents('bot.pid'));

// Vérifier si le processus est toujours en cours d'exécution
if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
    // Windows
    exec("tasklist /FI \"PID eq $pid\"", $output);
    $isRunning = count($output) > 1;
} else {
    // Linux/Unix
    exec("ps -p $pid", $output);
    $isRunning = count($output) > 1;
}

if (!$isRunning) {
    // Le bot s'est arrêté de manière inattendue
    @unlink('bot.pid');
    file_put_contents('bot.log', date('[Y-m-d H:i:s]') . " Le bot s'est arrêté de manière inattendue\n", FILE_APPEND);
    exit(1);
}

// Vérifier s'il y a des commandes en attente
$commandFile = 'bot_command.tmp';
if (file_exists($commandFile)) {
    // Lire et supprimer le fichier de commandes
    $commands = file($commandFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    @unlink($commandFile);
    
    // Envoyer les commandes au bot
    foreach ($commands as $cmd) {
        if (!empty(trim($cmd))) {
            file_put_contents('bot.log', date('[Y-m-d H:i:s]') . " [COMMANDE] $cmd\n", FILE_APPEND);
            // Ici, vous pourriez ajouter la logique pour envoyer la commande au bot
            // Par exemple, via un socket ou un fichier partagé
        }
    }
}

// Vérifier la taille du fichier de log et le tronquer si nécessaire
$logFile = 'bot.log';
if (file_exists($logFile) && filesize($logFile) > 5 * 1024 * 1024) { // 5 Mo
    $logs = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $logs = array_slice($logs, -1000); // Garder les 1000 dernières lignes
    file_put_contents($logFile, implode("\n", $logs) . "\n");
}

exit(0);
