<?php
header('Content-Type: application/json');

// Vérifier si le fichier PID existe
if (file_exists('bot.pid')) {
    $pid = trim(file_get_contents('bot.pid'));
    
    // Arrêter le processus du bot
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // Windows
        exec("taskkill /F /PID $pid");
    } else {
        // Linux/Unix
        exec("kill -9 $pid");
    }
    
    // Supprimer le fichier PID
    @unlink('bot.pid');
}

// Répondre avec succès
echo json_encode(['status' => 'success', 'message' => 'Bot arrêté avec succès']);
