<?php
// bot_runner.php
require_once 'vendor/autoload.php';

// Récupérer les arguments de la ligne de commande
$server = $argv[1] ?? 'localhost';
$port = (int)($argv[2] ?? 25565);
$username = $argv[3] ?? 'MinecraftBot';

// Configuration du bot
$options = [
    'host' => $server,
    'port' => $port,
    'username' => $username,
    'version' => '1.16.5',
    'auth' => 'offline', // Mode hors ligne pour les comptes crackés
    'viewDistance' => 'tiny',
    'hideErrors' => true
];

try {
    // Créer une instance du bot
    $bot = new \AdrianTimpau\PhpMinecraft\Client($options);
    
    // Événement de connexion réussie
    $bot->on('login', function() use ($bot, $username) {
        error_log("[$username] Connecté au serveur");
        $bot->chat("/say Bonjour ! Je suis $username, un bot de test.");
    });
    
    // Répondre aux messages dans le chat
    $bot->on('chat', function($message) use ($bot, $username) {
        $text = strtolower($message);
        if (strpos($text, 'bonjour') !== false) {
            $bot->chat("Salut ! Comment ça va ?");
        } elseif (strpos($text, 'heure') !== false) {
            $bot->chat("Il est " . date('H:i:s'));
        }
    });
    
    // Garder le bot actif
    while (true) {
        $bot->update();
        usleep(50000); // 50ms
        
        // Toutes les 5 minutes, envoyer un message pour éviter le kick d'inactivité
        static $lastMessage = 0;
        if (time() - $lastMessage > 300) {
            $bot->chat("."); // Message invisible
            $lastMessage = time();
        }
    }
    
} catch (Exception $e) {
    error_log("Erreur du bot: " . $e->getMessage());
    exit(1);
}
