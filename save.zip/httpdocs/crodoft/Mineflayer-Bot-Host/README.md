# Contrôleur de Bot Minecraft

Une application web pour contrôler un bot Minecraft qui reste connecté 24/7 à un serveur spécifié.

## Fonctionnalités

- Interface web intuitive
- Support des comptes crackés
- Connexion à n'importe quel serveur Minecraft
- Réponses automatiques aux messages
- Anti-déconnexion automatique

## Prérequis

- Serveur Linux/Windows avec PHP 7.4+
- Accès SSH (recommandé)
- Serveur Minecraft en mode hors ligne (cracké)
- Extensions PHP requises : sockets, mbstring, json

## Installation

1. Téléchargez les fichiers sur votre serveur :
   ```bash
   git clone [URL_DU_DEPOT] /var/www/minecraft-bot
   cd /var/www/minecraft-bot
   ```

2. Rendez le script d'installation exécutable et lancez-le :
   ```bash
   chmod +x install.sh
   ./install.sh
   ```

3. Modifiez le fichier `.env` selon votre configuration :
   ```
   SERVER_HOST=adresse_du_serveur
   SERVER_PORT=25565
   BOT_USERNAME=MonSuperBot
   ```

## Configuration du serveur web

### Apache
Assurez-vous que le module `mod_rewrite` est activé et que le `AllowOverride` est configuré sur `All` pour le répertoire du projet.

### Nginx
Ajoutez cette configuration à votre hôte virtuel :
```nginx
location / {
    try_files $uri $uri/ /index.php?$query_string;
}
```

## Utilisation

1. Accédez à l'interface web via votre navigateur :
   ```
   npm start
   ```
   ou en mode développement avec rechargement automatique :
   ```
   npm run dev
   ```

2. Ouvrez votre navigateur et accédez à :
   ```
   http://localhost:3000
   ```

3. Remplissez les champs :
   - IP du serveur Minecraft
   - Nom d'utilisateur
   - Mot de passe (uniquement pour les comptes non-premium/crackés)

4. Cliquez sur "Se connecter"

## Sécurité

- Ne partagez jamais vos identifiants Minecraft
- Ne laissez pas le bot connecté sur des serveurs non fiables
- Utilisez ce bot de manière responsable et conformément aux règles des serveurs

## Dépannage

- Assurez-vous que le port spécifié est disponible
- Vérifiez vos identifiants de connexion
- Consultez les journaux du serveur pour les erreurs

## Licence

Ce projet est sous licence MIT.
