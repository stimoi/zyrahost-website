#!/bin/bash
echo "Installation du contrôleur de bot Minecraft..."

# Vérifier si PHP est installé
if ! command -v php &> /dev/null; then
    echo "PHP n'est pas installé. Installation en cours..."
    sudo apt update
    sudo apt install -y php php-cli php-mbstring php-sockets composer
fi

# Vérifier si Composer est installé
if ! command -v composer &> /dev/null; then
    echo "Composer n'est pas installé. Installation en cours..."
    php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
    php composer-setup.php --install-dir=/usr/local/bin --filename=composer
    php -r "unlink('composer-setup.php');"
fi

# Installer les dépendances PHP
echo "Installation des dépendances PHP..."
composer install --no-dev --optimize-autoloader

# Créer un fichier .env s'il n'existe pas
if [ ! -f .env ]; then
    echo "Création du fichier de configuration..."
    cat > .env <<EOL
# Configuration du serveur Minecraft
SERVER_HOST=localhost
SERVER_PORT=25565
BOT_USERNAME=MinecraftBot

# Paramètres avancés
PHP_PATH=$(which php)
EOL
fi

# Rendre les scripts exécutables
chmod +x bot_runner.php
chmod +x bot.php

# Créer un fichier .htaccess pour la sécurité
cat > .htaccess <<EOL
# Désactiver l'accès aux fichiers sensibles
<FilesMatch "^\.|composer\.(json|lock)|package\.json$|README\.md$">
    Order allow,deny
    Deny from all
</FilesMatch>

# Activer la réécriture d'URL
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    
    # Rediriger vers HTTPS si disponible
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
    
    # Bloquer l'accès aux dossiers
    RewriteRule ^(vendor|node_modules|.git) - [F,L]
    
    # Autoriser l'accès aux fichiers nécessaires
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^(.*)$ index.php [L,QSA]
</IfModule>
EOL

echo "Installation terminée !"
echo "1. Modifiez le fichier .env avec vos paramètres"
echo "2. Accédez à l'interface web avec votre navigateur"
echo "3. Connectez-vous avec les identifiants du bot"
