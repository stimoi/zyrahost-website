<?php
session_start();
require_once 'vendor/autoload.php';

// Configuration du bot
$config = [
    'host' => $_ENV['SERVER_HOST'] ?? 'localhost',
    'port' => (int)($_ENV['SERVER_PORT'] ?? 25565),
    'username' => $_ENV['BOT_USERNAME'] ?? 'MinecraftBot',
    'version' => '1.16.5',
    'auth' => 'offline'
];

// Vérifier si le bot est en cours d'exécution
$isRunning = false;
if (file_exists('bot.pid')) {
    $pid = trim(file_get_contents('bot.pid'));
    $output = [];
    exec("ps -p $pid", $output);
    $isRunning = count($output) > 1;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contrôleur de Bot Minecraft</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 2rem;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: #4CAF50;
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 1.5rem;
        }
        .btn-success {
            background-color: #4CAF50;
            border: none;
            padding: 10px 25px;
        }
        .btn-danger {
            padding: 10px 25px;
        }
        .status-indicator {
            display: inline-block;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            margin-right: 8px;
        }
        .status-online {
            background-color: #28a745;
        }
        .status-offline {
            background-color: #dc3545;
        }
        .log-container {
            height: 400px;
            overflow-y: auto;
            background-color: #1e1e1e;
            color: #f0f0f0;
            padding: 15px;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
        }
        .log-entry {
            margin-bottom: 5px;
            line-height: 1.4;
        }
        .log-time {
            color: #6c757d;
            margin-right: 10px;
        }
        .command-input {
            border-top-left-radius: 8px;
            border-bottom-left-radius: 8px;
            border: 1px solid #ced4da;
            padding: 10px 15px;
        }
        .command-btn {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center">
                        <h2 class="mb-0">Contrôleur de Bot Minecraft</h2>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <div>
                                <h4 class="mb-0">
                                    <span class="status-indicator status-<?= $isRunning ? 'online' : 'offline' ?>"></span>
                                    Statut: <?= $isRunning ? 'En ligne' : 'Hors ligne' ?>
                                </h4>
                                <?php if ($isRunning): ?>
                                    <small class="text-muted">Connecté à <?= htmlspecialchars($config['host'] . ':' . $config['port']) ?></small>
                                <?php endif; ?>
                            </div>
                            <div>
                                <?php if (!$isRunning): ?>
                                    <button id="startBtn" class="btn btn-success">
                                        <i class="fas fa-play me-2"></i>Démarrer le bot
                                    </button>
                                <?php else: ?>
                                    <button id="stopBtn" class="btn btn-danger">
                                        <i class="fas fa-stop me-2"></i>Arrêter le bot
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>

                        <?php if (!$isRunning): ?>
                            <div class="mb-4">
                                <h5>Configuration du bot</h5>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="server" class="form-label">Adresse du serveur</label>
                                        <input type="text" class="form-control" id="server" value="<?= htmlspecialchars($config['host']) ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label for="port" class="form-label">Port</label>
                                        <input type="number" class="form-control" id="port" value="<?= $config['port'] ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label for="username" class="form-label">Nom du bot</label>
                                        <input type="text" class="form-control" id="username" value="<?= htmlspecialchars($config['username']) ?>">
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="mb-4">
                            <h5>Console du bot</h5>
                            <div class="log-container mb-3" id="logContainer">
                                <div class="log-entry">
                                    <span class="log-time">[<?= date('H:i:s') ?>]</span>
                                    <span>Bienvenue sur le panneau de contrôle du bot Minecraft</span>
                                </div>
                                <?php if ($isRunning && file_exists('bot.log')): ?>
                                    <?php 
                                    $logs = file('bot.log', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                                    $logs = array_slice($logs, -50); // Dernières 50 lignes
                                    foreach ($logs as $log): 
                                    ?>
                                        <div class="log-entry"><?= htmlspecialchars($log) ?></div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($isRunning): ?>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control command-input" id="commandInput" placeholder="Entrez une commande...">
                                    <button class="btn btn-outline-secondary command-btn" type="button" id="sendCommand">
                                        <i class="fas fa-paper-plane"></i>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-3 text-muted">
                    <small>Minecraft Bot Controller &copy; <?= date('Y') ?></small>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    $(document).ready(function() {
        const logContainer = $('#logContainer');
        
        // Faire défiler vers le bas automatiquement
        function scrollToBottom() {
            logContainer.scrollTop(logContainer[0].scrollHeight);
        }
        
        // Ajouter un message dans la console
        function addLog(message, isError = false) {
            const time = new Date().toLocaleTimeString();
            const logEntry = $(`
                <div class="log-entry" style="color: ${isError ? '#ff6b6b' : '#f0f0f0'}">
                    <span class="log-time">[${time}]</span>
                    <span>${message}</span>
                </div>
            `);
            logContainer.append(logEntry);
            scrollToBottom();
        }
        
        // Mettre à jour les logs
        function updateLogs() {
            if (!<?= $isRunning ? 'false' : 'true' ?>) return;
            
            $.get('bot.log?t=' + new Date().getTime(), function(data) {
                const logs = data.trim().split('\n');
                const currentLogs = logContainer.text();
                
                logs.forEach(log => {
                    if (log && !currentLogs.includes(log)) {
                        addLog(log);
                    }
                });
            }).fail(function() {
                // Ne rien faire en cas d'erreur
            });
        }
        
        // Démarrer le bot
        $('#startBtn').click(function() {
            const server = $('#server').val().trim();
            const port = $('#port').val().trim();
            const username = $('#username').val().trim();
            
            if (!server || !port || !username) {
                addLog('Veuillez remplir tous les champs', true);
                return;
            }
            
            const btn = $(this);
            btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Démarrage...');
            
            $.post('bot.php', {
                server: server,
                port: port,
                username: username
            }, function(response) {
                if (response.status === 'success') {
                    location.reload();
                } else {
                    addLog('Erreur: ' + response.message, true);
                    btn.prop('disabled', false).html('<i class="fas fa-play me-2"></i>Démarrer le bot');
                }
            }, 'json');
        });
        
        // Arrêter le bot
        $('#stopBtn').click(function() {
            if (confirm('Êtes-vous sûr de vouloir arrêter le bot ?')) {
                const btn = $(this);
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Arrêt...');
                
                $.post('stop_bot.php', function() {
                    location.reload();
                }).fail(function() {
                    location.reload();
                });
            }
        });
        
        // Envoyer une commande
        $('#commandInput').keypress(function(e) {
            if (e.which === 13) { // Touche Entrée
                sendCommand();
            }
        });
        
        $('#sendCommand').click(sendCommand);
        
        function sendCommand() {
            const command = $('#commandInput').val().trim();
            if (!command) return;
            
            addLog('> ' + command);
            $('#commandInput').val('');
            
            $.post('command.php', { command: command }, function(response) {
                if (response.status !== 'success') {
                    addLog('Erreur: ' + response.message, true);
                }
            }, 'json');
        }
        
        // Mettre à jour les logs toutes les 2 secondes
        setInterval(updateLogs, 2000);
        
        // Initialiser le défilement
        scrollToBottom();
    });
    </script>
</body>
</html>