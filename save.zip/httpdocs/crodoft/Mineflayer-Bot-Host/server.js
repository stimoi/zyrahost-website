const mineflayer = require('mineflayer');
const fs = require('fs');

// Récupérer les arguments
const server = process.argv[2] || 'localhost';
const username = process.argv[3] || 'Bot';
const password = process.argv[4] || '';

// Créer le bot
const bot = mineflayer.createBot({
    host: server,
    username: username,
    password: password || undefined,
    auth: password ? 'microsoft' : 'mojang',
    version: '1.8.9'
});

// Gestion des événements
bot.on('login', () => {
    console.log(`Connecté en tant que ${username} sur ${server}`);
    bot.chat('/login ' + (password || ''));
});

bot.on('end', (reason) => {
    console.log(`Déconnecté: ${reason}`);
    process.exit();
});

bot.on('error', (err) => {
    console.error('Erreur:', err);
    process.exit(1);
});

// Garder le bot actif
setInterval(() => {
    bot.setControlState('jump', true);
    setTimeout(() => bot.setControlState('jump', false), 100);
}, 30000);

// Écouter les commandes de la console
process.stdin.on('data', (data) => {
    const command = data.toString().trim();
    if (command === 'stop') {
        bot.quit('Arrêt demandé');
        process.exit();
    }
});