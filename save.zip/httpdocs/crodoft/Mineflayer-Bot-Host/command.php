<?php
header('Content-Type: application/json');

// Vérifier si une commande a été envoyée
if (!isset($_POST['command']) || empty(trim($_POST['command']))) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Aucune commande spécifiée']);
    exit;
}

$command = trim($_POST['command']);

// Vérifier si le bot est en cours d'exécution
if (!file_exists('bot.pid')) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Le bot n\'est pas en cours d\'exécution']);
    exit;
}

// Enregistrer la commande dans un fichier temporaire
$commandFile = 'bot_command.tmp';
file_put_contents($commandFile, $command . "\n", FILE_APPEND);

// Répondre avec succès
echo json_encode(['status' => 'success', 'message' => 'Commande envoyée']);
