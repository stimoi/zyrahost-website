<?php
// bot.php
require_once 'vendor/autoload.php';
use xPaw\MinecraftPing;
use xPaw\MinecraftPingException;

// Démarrer la session
session_start();

// Vérifier si c'est une requête AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    $server = filter_input(INPUT_POST, 'server', FILTER_SANITIZE_STRING) ?? '';
    $port = (int)(filter_input(INPUT_POST, 'port', FILTER_VALIDATE_INT) ?? 25565);
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING) ?? 'MinecraftBot';
    
    // Valider l'entrée
    if (empty($server) || empty($username)) {
        echo json_encode(['status' => 'error', 'message' => 'Veuillez remplir tous les champs']);
        exit;
    }
    
    try {
        // Vérifier si le serveur est en ligne
        $ping = new MinecraftPing($server, $port, 3);
        $serverInfo = $ping->Query();
        $ping->Close();
        
        if (!$serverInfo) {
            throw new Exception('Impossible de contacter le serveur');
        }
        
        // Démarrer le bot en arrière-plan
        $command = sprintf(
            'php %s %s %d %s > /dev/null 2>&1 & echo $!',
            escapeshellarg(__DIR__ . '/bot_runner.php'),
            escapeshellarg($server),
            $port,
            escapeshellarg($username)
        );
        
        $output = [];
        $pid = exec($command, $output, $return_var);
        
        if ($return_var === 0 && is_numeric($pid)) {
            $_SESSION['bot_pid'] = $pid;
            $_SESSION['bot_server'] = $server;
            $_SESSION['bot_username'] = $username;
            echo json_encode([
                'status' => 'success', 
                'message' => "Bot $username connecté à $server:$port"
            ]);
        } else {
            throw new Exception('Impossible de démarrer le bot');
        }
        
    } catch (Exception $e) {
        echo json_encode([
            'status' => 'error', 
            'message' => 'Erreur: ' . $e->getMessage()
        ]);
    }
    exit;
}

// Si ce n'est pas une requête AJAX, rediriger vers l'index
header('Location: index.php');
exit;
