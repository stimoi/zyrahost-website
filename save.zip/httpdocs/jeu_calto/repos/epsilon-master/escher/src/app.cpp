#include <escher/app.h>
#include <escher/window.h>
#include <poincare/pool.h>
extern "C" {
#include <assert.h>
}

namespace Escher {

void App::Snapshot::pack(App* app) {
  tidy();
  app->~App();
  assert(Poincare::Pool::sharedPool->numberOfObjects() == 0);
}

bool App::processEvent(Ion::Events::Event event) {
  Responder* responder = m_firstResponder;
  bool didHandleEvent = false;
  while (responder) {
    didHandleEvent = responder->handleEvent(event);
    if (didHandleEvent) {
      return true;
    }
    responder = responder->parentResponder();
  }
  return false;
}

void App::setFirstResponder(Responder* responder, bool force) {
  /* This flag is used only in DEBUG to ensure that
   * handleResponderChainEvent(didEnter) do not call setFirstResponder.
   * */
#if ASSERTIONS
  static bool preventRecursion = false;
  // TODO: Restore this behaviour
  // assert(force || !preventRecursion);
#endif
  if (!force && m_firstResponder == responder) {
    return;
  }
  Responder* previousResponder = m_firstResponder;
  m_firstResponder = responder;
  if (previousResponder) {
    Responder* commonAncestor =
        previousResponder->commonAncestorWith(m_firstResponder);
    Responder* leafResponder = previousResponder;
#if ASSERTIONS
    preventRecursion = true;
#endif
    while (leafResponder != commonAncestor) {
      leafResponder->willExitResponderChain(m_firstResponder);
      leafResponder = leafResponder->parentResponder();
    }
#if ASSERTIONS
    preventRecursion = false;
#endif
    previousResponder->willResignFirstResponder();
  }
  if (m_firstResponder) {
    constexpr int k_maxNumberOfResponders = 32;
    Responder* responderStack[k_maxNumberOfResponders];
    int index = 0;
    Responder* commonAncestor =
        m_firstResponder->commonAncestorWith(previousResponder);
    Responder* leafResponder = m_firstResponder;
#if ASSERTIONS
    preventRecursion = true;
#endif
    while (leafResponder != commonAncestor) {
      assert(index < k_maxNumberOfResponders);
      responderStack[index++] = leafResponder;
      leafResponder = leafResponder->parentResponder();
    }
    for (index--; index >= 0; index--) {
      responderStack[index]->didEnterResponderChain(previousResponder);
    }
#if ASSERTIONS
    preventRecursion = false;
    (void)preventRecursion;
#endif
    m_firstResponder->didBecomeFirstResponder();
  }
}

void App::displayModalViewController(ViewController* vc,
                                     float verticalAlignment,
                                     float horizontalAlignment,
                                     KDMargins margins, bool growingOnly) {
  m_modalViewController.dismissPotentialModal();
  m_modalViewController.displayModalViewController(
      vc, verticalAlignment, horizontalAlignment, margins, growingOnly);
}

void App::displayWarning(I18n::Message warningMessage, bool specialExitKeys) {
  m_warningController.setLabel(warningMessage, specialExitKeys);
  displayModalViewController(&m_warningController, KDGlyph::k_alignCenter,
                             KDGlyph::k_alignCenter);
}

void App::didBecomeActive(Window* window) {
  View* view = m_modalViewController.view();
  m_modalViewController.initView();
  window->setContentView(view);
  m_modalViewController.viewWillAppear();
  setFirstResponder(&m_modalViewController);
}

void App::willBecomeInactive() {
  setFirstResponder(nullptr);
  m_modalViewController.viewDidDisappear();
}

}  // namespace Escher
