#ifndef ESCHER_INIT_H
#define ESCHER_INIT_H

namespace Escher {

void Init();

}

#endif
