#ifndef LIBA_TEST_HELPERS_H
#define LIBA_TEST_HELPERS_H

#define assert_signed(type) assert((type)-1 < 0)
#define assert_unsigned(type) assert((type)-1 >= 0)

#endif
