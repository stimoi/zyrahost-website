#ifndef LIBA_CTYPE_H
#define LIBA_CTYPE_H

int isupper(int c);
int isxdigit(int c);
int isdigit(int c);
int tolower(int c);

#endif
