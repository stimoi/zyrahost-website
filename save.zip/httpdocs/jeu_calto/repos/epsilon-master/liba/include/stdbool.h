#ifndef LIBA_STDBOOL_H
#define LIBA_STDBOOL_H

#ifndef __cplusplus

typedef _Bool bool;

#define true 1
#define false 0

#endif

#endif
