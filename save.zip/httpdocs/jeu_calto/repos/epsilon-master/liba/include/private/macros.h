#ifndef LIBA_MACROS_H
#define LIBA_MACROS_H

#ifdef __cplusplus
#define LIBA_BEGIN_DECLS extern "C" {
#define LIBA_END_DECLS }
#else
#define LIBA_BEGIN_DECLS
#define LIBA_END_DECLS
#endif

#endif
