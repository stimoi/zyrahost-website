// OpenBSD requires this file to be present
