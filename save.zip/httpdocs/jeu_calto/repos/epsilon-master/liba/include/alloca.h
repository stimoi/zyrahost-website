#ifndef LIBA_ALLOCA_H
#define LIBA_ALLOCA_H

#define alloca(size) __builtin_alloca(size)

#endif
