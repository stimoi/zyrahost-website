#ifndef LIBA_STRINGS_H
#define LIBA_STRINGS_H

#include <stdlib.h>

void bzero(void* s, size_t n);

#endif
