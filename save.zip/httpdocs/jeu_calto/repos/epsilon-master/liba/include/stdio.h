#ifndef LIBA_STDIO_H
#define LIBA_STDIO_H

#define stdin 0
#define stdout 0
#define EOF 0

typedef void FILE;

#endif
