#ifndef LIBA_UNISTD_H
#define LIBA_UNISTD_H

#define SEEK_SET 0
#define SEEK_CUR 1

#endif
