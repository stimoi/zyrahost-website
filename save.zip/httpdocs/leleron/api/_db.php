<?php

declare(strict_types=1);

require_once __DIR__ . '/_env.php';

function db(): PDO {
    static $pdo;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $host = env_get('DB_HOST');
    $name = env_get('DB_NAME');
    $user = env_get('DB_USER');
    $pass = env_get('DB_PASS');
    $port = env_get('DB_PORT', '3306');

    if (!$host || !$name || !$user) {
        throw new RuntimeException('DB non configurée (DB_HOST/DB_NAME/DB_USER)');
    }

    if (str_contains($host, ':')) {
        [$hostOnly, $maybePort] = explode(':', $host, 2);
        if ($hostOnly !== '') {
            $host = $hostOnly;
        }
        if ($maybePort !== '') {
            $port = $maybePort;
        }
    }

    $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
    $pdo = new PDO($dsn, $user, $pass ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    return $pdo;
}
