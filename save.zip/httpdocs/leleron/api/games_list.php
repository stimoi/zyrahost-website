<?php

declare(strict_types=1);

require_once __DIR__ . '/_http.php';
require_once __DIR__ . '/_db.php';

cors();

try {
    $stmt = db()->query('SELECT id, name, author, description, link, image, created_at FROM leleron ORDER BY created_at DESC, id DESC');
    $rows = $stmt->fetchAll();
    send_json(['ok' => true, 'games' => $rows]);
} catch (Throwable $e) {
    send_json(['ok' => false, 'error' => 'db_error'], 500);
}
