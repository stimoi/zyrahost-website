<?php

declare(strict_types=1);

require_once __DIR__ . '/_http.php';

cors();
send_json([
    'ok' => true,
    'endpoints' => [
        'GET /api/games_list.php',
        'POST /api/games_add.php'
    ]
]);
