<?php

declare(strict_types=1);

require_once __DIR__ . '/_http.php';
require_once __DIR__ . '/_db.php';

cors();

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    send_json(['ok' => false, 'error' => 'method_not_allowed'], 405);
}

$body = read_json_body();

$name = trim((string)($body['name'] ?? ''));
$author = trim((string)($body['author'] ?? ''));
$description = trim((string)($body['desc'] ?? $body['description'] ?? ''));
$link = trim((string)($body['link'] ?? ''));
$image = trim((string)($body['image'] ?? ''));

if ($name === '' || $author === '' || $description === '' || $link === '' || $image === '') {
    send_json(['ok' => false, 'error' => 'validation_error'], 400);
}

if (mb_strlen($name) > 60 || mb_strlen($author) > 40 || mb_strlen($description) > 300) {
    send_json(['ok' => false, 'error' => 'validation_error'], 400);
}

try {
    $pdo = db();

    $stmt = $pdo->prepare('INSERT INTO leleron (name, author, description, link, image) VALUES (:name, :author, :description, :link, :image)');
    $stmt->execute([
        ':name' => $name,
        ':author' => $author,
        ':description' => $description,
        ':link' => $link,
        ':image' => $image,
    ]);

    send_json(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);
} catch (PDOException $e) {
    if ((int)($e->errorInfo[1] ?? 0) === 1062) {
        send_json(['ok' => false, 'error' => 'duplicate'], 409);
    }
    send_json(['ok' => false, 'error' => 'db_error'], 500);
} catch (Throwable $e) {
    send_json(['ok' => false, 'error' => 'db_error'], 500);
}
