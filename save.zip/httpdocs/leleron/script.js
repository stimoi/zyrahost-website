/* ============================================================
   CONCOURS ROBLOX – LELERON  |  script.js
   ============================================================ */

/* ================================================================
   1. BASE DE DONNÉES DES JEUX (simulée)
   ================================================================ */

/**
 * Tableau principal des jeux soumis.
 * Chaque objet représente un jeu participant au concours.
 * Structure :
 *  - id       : identifiant unique
 *  - name     : nom du jeu
 *  - author   : pseudo Roblox du créateur
 *  - desc     : description du jeu
 *  - image    : URL de l'image de couverture
 *  - link     : URL Roblox du jeu
 */
const gamesDatabase = [];

async function fetchGames() {
  const res = await fetch('api/games_list.php', { cache: 'no-store' });
  const data = await res.json();
  if (!data || data.ok !== true || !Array.isArray(data.games)) {
    throw new Error('bad_response');
  }

  gamesDatabase.length = 0;
  data.games.forEach(g => {
    gamesDatabase.push({
      id: g.id,
      name: g.name,
      author: g.author,
      desc: g.description,
      link: g.link,
      image: g.image
    });
  });

  renderGames(gamesDatabase);
}

/* ================================================================
   2. DATE DE FIN DU CONCOURS (2 semaines à partir du lancement)
   Modifie cette date selon la vraie date de début du concours.
   ================================================================ */

// Départ réel du concours : 21 février 2026 à 12:52:00 (heure locale)
const CONTEST_START = new Date(2026, 1, 21, 12, 52, 0, 0);
// Date de fin : 14 jours après le départ réel
const CONTEST_END = new Date(CONTEST_START.getTime() + 14 * 24 * 60 * 60 * 1000);

/* ================================================================
   3. UTILITAIRES
   ================================================================ */

/**
 * Affiche un toast de notification en bas de l'écran.
 * @param {string} msg     - Le message à afficher
 * @param {string} type    - 'success' | 'error' | '' (neutre)
 * @param {number} duration - Durée d'affichage en ms (défaut: 3000)
 */
function showToast(msg, type = '', duration = 3000) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.className = `toast ${type} show`;
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => {
    toast.classList.remove('show');
  }, duration);
}

/**
 * Sanitise une chaîne HTML pour éviter les injections XSS.
 * @param {string} str
 * @returns {string}
 */
function sanitize(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/**
 * Tronque un texte à un nombre maximum de caractères.
 * @param {string} text
 * @param {number} max
 * @returns {string}
 */
function truncate(text, max = 120) {
  return text.length > max ? text.slice(0, max) + '…' : text;
}

/* ================================================================
   4. GÉNÉRATION DES CARTES JEUX
   ================================================================ */

/**
 * Crée l'élément HTML d'une carte de jeu.
 * @param {Object} game - Objet jeu issu de gamesDatabase
 * @param {number} delay - Délai d'animation (ms)
 * @returns {HTMLElement}
 */
function createGameCard(game, delay = 0) {
  const card = document.createElement('article');
  card.className = 'game-card';
  card.style.animationDelay = `${delay}ms`;
  card.dataset.id = game.id;

  card.innerHTML = `
    <div class="card-img-wrap">
      <img
        src="${sanitize(game.image)}"
        alt="Capture du jeu ${sanitize(game.name)}"
        loading="lazy"
        onerror="this.src='https://via.placeholder.com/600x300/0a0a1a/00d4ff?text=Image+non+disponible'"
      />
      <div class="card-img-overlay"></div>
      <span class="card-badge">✅ Soumis</span>
    </div>
    <div class="card-body">
      <p class="card-author">👤 ${sanitize(game.author)}</p>
      <h3 class="card-title">${sanitize(game.name)}</h3>
      <p class="card-desc">${sanitize(truncate(game.desc))}</p>
      <div class="card-footer">
        <a
          href="${sanitize(game.link)}"
          target="_blank"
          rel="noopener noreferrer"
          class="card-play-btn"
          onclick="event.stopPropagation()"
        >🎮 Jouer</a>
        <button class="card-detail-btn" aria-label="Voir les détails de ${sanitize(game.name)}">
          Détails →
        </button>
      </div>
    </div>
  `;

  // Ouvrir la modal au clic sur "Détails"
  card.querySelector('.card-detail-btn').addEventListener('click', () => openModal(game));

  // Ouvrir la modal au clic sur la carte (sauf sur les liens)
  card.addEventListener('click', (e) => {
    if (!e.target.closest('a')) openModal(game);
  });

  return card;
}

/**
 * Rend toutes les cartes dans la grille.
 * @param {Array} games - Tableau de jeux à afficher
 */
function renderGames(games) {
  const grid = document.getElementById('games-grid');
  const noResults = document.getElementById('no-results');
  const count = document.getElementById('game-count');

  grid.innerHTML = '';

  if (games.length === 0) {
    noResults.style.display = 'block';
    count.textContent = 'Aucun jeu ne correspond à ta recherche.';
    return;
  }

  noResults.style.display = 'none';
  count.textContent = `${games.length} jeu${games.length > 1 ? 'x' : ''} soumis 🎮`;

  games.forEach((game, i) => {
    const card = createGameCard(game, i * 80);
    grid.appendChild(card);
  });
}

/* ================================================================
   5. MODAL DÉTAILS
   ================================================================ */

/** Ouvre la modal avec les données d'un jeu. */
function openModal(game) {
  const overlay = document.getElementById('modal-overlay');
  document.getElementById('modal-img').src     = game.image;
  document.getElementById('modal-img').alt     = game.name;
  document.getElementById('modal-author').textContent = `👤 ${game.author}`;
  document.getElementById('modal-title').textContent  = game.name;
  document.getElementById('modal-desc').textContent   = game.desc;
  document.getElementById('modal-link').href    = game.link;
  overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
}

/** Ferme la modal. */
function closeModal() {
  document.getElementById('modal-overlay').classList.remove('open');
  document.body.style.overflow = '';
}

// Bouton fermer
document.getElementById('modal-close').addEventListener('click', closeModal);

// Clic sur l'overlay (fond) ferme la modal
document.getElementById('modal-overlay').addEventListener('click', (e) => {
  if (e.target === e.currentTarget) closeModal();
});

// Touche Échap ferme la modal
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeModal();
});

/* ================================================================
   6. RECHERCHE EN TEMPS RÉEL
   ================================================================ */

document.getElementById('search-input').addEventListener('input', function () {
  const query = this.value.trim().toLowerCase();

  const filtered = gamesDatabase.filter(game =>
    game.name.toLowerCase().includes(query) ||
    game.author.toLowerCase().includes(query) ||
    game.desc.toLowerCase().includes(query)
  );

  renderGames(filtered);
});

/* ================================================================
   7. FORMULAIRE DE SOUMISSION
   ================================================================ */

const form = document.getElementById('submit-form');
const descArea = document.getElementById('game-desc');

// Compteur de caractères pour la description
descArea.addEventListener('input', function () {
  document.getElementById('char-count').textContent = `${this.value.length} / 300`;
});

/**
 * Valide le formulaire.
 * @returns {boolean} true si le formulaire est valide
 */
function validateForm() {
  let valid = true;

  const fields = [
    { id: 'game-name',   errId: 'err-name',   label: 'Le nom du jeu est requis.' },
    { id: 'game-author', errId: 'err-author',  label: 'Ton pseudo Roblox est requis.' },
    { id: 'game-desc',   errId: 'err-desc',    label: 'Une description est requise.' },
    { id: 'game-link',   errId: 'err-link',    label: 'Le lien Roblox est requis.', type: 'url', prefix: 'roblox.com' },
    { id: 'game-image',  errId: 'err-image',   label: "L'URL de l'image est requise.", type: 'url' }
  ];

  fields.forEach(f => {
    const el  = document.getElementById(f.id);
    const err = document.getElementById(f.errId);
    const val = el.value.trim();

    el.classList.remove('error');
    err.textContent = '';

    if (!val) {
      err.textContent = f.label;
      el.classList.add('error');
      valid = false;
      return;
    }

    // Validation URL
    if (f.type === 'url') {
      try {
        const url = new URL(val);
        if (!['http:', 'https:'].includes(url.protocol)) throw new Error();
        if (f.prefix && !val.includes(f.prefix)) {
          err.textContent = `Le lien doit contenir "${f.prefix}".`;
          el.classList.add('error');
          valid = false;
        }
      } catch {
        err.textContent = `Veuillez entrer une URL valide (https://...).`;
        el.classList.add('error');
        valid = false;
      }
    }
  });

  return valid;
}

/**
 * Ajoute un nouveau jeu à la base et re-rend la grille.
 */
form.addEventListener('submit', function (e) {
  e.preventDefault();

  if (!validateForm()) {
    showToast('❌ Corrige les erreurs avant de soumettre.', 'error');
    return;
  }

  // Récupérer les valeurs
  const name   = document.getElementById('game-name').value.trim();
  const author = document.getElementById('game-author').value.trim();
  const desc   = document.getElementById('game-desc').value.trim();
  const link   = document.getElementById('game-link').value.trim();
  const image  = document.getElementById('game-image').value.trim();

  // Vérifier les doublons de nom
  const duplicate = gamesDatabase.find(g => g.name.toLowerCase() === name.toLowerCase());
  if (duplicate) {
    document.getElementById('err-name').textContent = 'Un jeu avec ce nom existe déjà.';
    document.getElementById('game-name').classList.add('error');
    return;
  }

  // Créer le nouvel objet jeu
  const newGame = {
    id: Date.now(),
    name,
    author,
    desc,
    link,
    image
  };

  document.getElementById('submit-btn').disabled = true;
  document.querySelector('#submit-btn .btn-text').style.display = 'none';
  document.querySelector('#submit-btn .btn-loader').style.display = '';

  fetch('api/games_add.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(newGame)
  }).then(async (res) => {
    const data = await res.json().catch(() => null);
    if (!res.ok || !data || data.ok !== true) {
      if (res.status === 409) {
        throw new Error('duplicate');
      }
      throw new Error('save_failed');
    }
  }).then(async () => {
    showToast('🎉 Ton jeu a été soumis avec succès !', 'success');

    // Réinitialiser le formulaire
    form.reset();
    document.getElementById('char-count').textContent = '0 / 300';

    // Nettoyer les états d'erreur
    form.querySelectorAll('.form-error').forEach(el => el.textContent = '');
    form.querySelectorAll('input, textarea').forEach(el => el.classList.remove('error'));

    // Animation : scroller jusqu'à la grille
    document.getElementById('soumissions').scrollIntoView({ behavior: 'smooth', block: 'start' });

    await fetchGames();
  }).catch((err) => {
    if (String(err && err.message) === 'duplicate') {
      showToast('❌ Ce jeu a déjà été soumis (lien déjà existant).', 'error');
      return;
    }
    showToast('❌ Erreur lors de la sauvegarde. Vérifie la base de données.', 'error');
  }).finally(() => {
    document.getElementById('submit-btn').disabled = false;
    document.querySelector('#submit-btn .btn-text').style.display = '';
    document.querySelector('#submit-btn .btn-loader').style.display = 'none';
  });
});

/* ================================================================
   8. COMPTE À REBOURS
   ================================================================ */

/**
 * Met à jour le compte à rebours toutes les secondes.
 */
function updateCountdown() {
  const now    = new Date();
  const diff   = CONTEST_END - now;
  const bar    = document.getElementById('countdown').closest('.countdown-bar');

  if (diff <= 0) {
    // Concours terminé
    document.getElementById('cd-days').textContent  = '00';
    document.getElementById('cd-hours').textContent = '00';
    document.getElementById('cd-min').textContent   = '00';
    document.getElementById('cd-sec').textContent   = '00';
    document.querySelector('.countdown-label').textContent = '🏁 Le concours est terminé !';
    if (bar) bar.classList.add('ended');
    return;
  }

  const days  = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const mins  = Math.floor((diff % 3600000) / 60000);
  const secs  = Math.floor((diff % 60000) / 1000);

  // Padding avec zéros
  const pad = n => String(n).padStart(2, '0');

  document.getElementById('cd-days').textContent  = pad(days);
  document.getElementById('cd-hours').textContent = pad(hours);
  document.getElementById('cd-min').textContent   = pad(mins);
  document.getElementById('cd-sec').textContent   = pad(secs);
}

// Lancement immédiat + rafraîchissement chaque seconde
updateCountdown();
setInterval(updateCountdown, 1000);

/* ================================================================
   9. ANNÉE DYNAMIQUE (FOOTER)
   ================================================================ */
document.getElementById('footer-year').textContent = new Date().getFullYear();

/* ================================================================
   10. SCROLL REVEAL (Intersection Observer)
   ================================================================ */

/**
 * Observe les éléments `.reveal` et leur ajoute la classe `.visible`
 * dès qu'ils entrent dans le viewport (animation au scroll).
 */
const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        // On arrête d'observer une fois l'animation déclenchée
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.12 }
);

// Observer tous les éléments reveal
document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

/* ================================================================
   11. NAV ACTIVE AU SCROLL (highlight du lien courant)
   ================================================================ */

const navLinks  = document.querySelectorAll('.sticky-nav a');
const sections  = ['presentation', 'soumissions', 'soumettre'].map(id => document.getElementById(id));

const navObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.id;
        navLinks.forEach(link => {
          link.classList.toggle('active', link.getAttribute('href') === `#${id}`);
        });
      }
    });
  },
  { threshold: 0.35 }
);

sections.forEach(s => s && navObserver.observe(s));

/* ================================================================
   12. INITIALISATION
   ================================================================ */

// Rendu initial de tous les jeux
renderGames(gamesDatabase);

fetchGames().catch(() => {
  showToast('❌ Impossible de charger les jeux (API).', 'error');
});