<?php
/*
 admin.php - Page d'administration du système de coins
 - Monitoring des pages fonctionnelles
 - Gestion des utilisateurs et coins
 - Système de recherche et modification
*/

session_start();

// Paramètres DB
$db_host = 'localhost:3306';
$db_name = 'mttljx_zyrahostf_db';
$db_user = 'sti_moi';
$db_pass = 'pj32~lH36';

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8",
        $db_user,
        $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    die("Erreur de connexion à la base de données.");
}

// Vérifier si l'utilisateur est admin (pseudo ou email spécifique)
$stmt = $pdo->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->execute([(int)$_SESSION['user_id']]);
$currentUser = $stmt->fetch(PDO::FETCH_ASSOC);

$isAdmin = false;
if ($currentUser) {
    $isAdmin = ($currentUser['username'] === 'sti_moi') || ($currentUser['email'] === 'sti_moi@outlook.com');
}

if (!$isAdmin) {
    header("HTTP/1.0 403 Forbidden");
    exit("Accès réservé à l'administrateur");
}

$success_msg = "";
$error_msg = "";

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8",
        $db_user,
        $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    die("Erreur de connexion à la base de données.");
}

// Traitement des actions admin
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_coins'])) {
        $user_id = (int)$_POST['user_id'];
        $new_coins = (int)$_POST['new_coins'];
        
        if ($new_coins >= 0) {
            $stmt = $pdo->prepare("UPDATE users SET coins = ? WHERE id = ?");
            $stmt->execute([$new_coins, $user_id]);
            $success_msg = "Coins de l'utilisateur #$user_id mis à jour avec succès";
        } else {
            $error_msg = "Le nombre de coins ne peut pas être négatif";
        }
    }
    
    if (isset($_POST['add_coins'])) {
        $user_id = (int)$_POST['user_id'];
        $add_coins = (int)$_POST['add_coins'];
        
        if ($add_coins > 0) {
            $stmt = $pdo->prepare("UPDATE users SET coins = coins + ? WHERE id = ?");
            $stmt->execute([$add_coins, $user_id]);
            $success_msg = "+$add_coins coins ajoutés à l'utilisateur #$user_id";
        } else {
            $error_msg = "Le nombre de coins à ajouter doit être positif";
        }
    }
}

// Récupérer tous les utilisateurs
$search = $_GET['search'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

$stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username LIKE ? OR id LIKE ?");
$stmt->execute(["%$search%", "%$search%"]);
$total_users = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT id, username, email, coins, created_at FROM users WHERE username LIKE ? OR id LIKE ? ORDER BY coins DESC LIMIT ? OFFSET ?");
$stmt->execute(["%$search%", "%$search%", $limit, $offset]);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total_pages = ceil($total_users / $limit);

// Monitoring des pages coins
$coin_pages = [
    'coins.php' => 'Hub principal',
    'coins--pub.php' => 'Publicités',
    'coins--discord.php' => 'Statut Discord',
    'coins--daily.php' => 'Récompense quotidienne',
    'coins--premium.php' => 'Avantages Premium',
    'coins--shop.php' => 'Boutique Coins',
    'coins--referral.php' => 'Parrainage'
];

$page_status = [];
foreach ($coin_pages as $file => $name) {
    $file_path = __DIR__ . '/' . $file;
    $page_status[$file] = [
        'name' => $name,
        'exists' => file_exists($file_path),
        'readable' => is_readable($file_path),
        'size' => file_exists($file_path) ? filesize($file_path) : 0,
        'modified' => file_exists($file_path) ? date('d/m/Y H:i', filemtime($file_path)) : 'N/A'
    ];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Administration - ZyraHost Coins</title>
<style>
:root{
  --bg:#0f0f12;
  --card:#121216;
  --muted:#9aa0a6;
  --accent:#5865F2;
  --accent-2:#6d7cff;
  --success:#10b981;
  --error:#ef4444;
  --warning:#f59e0b;
}
*{box-sizing:border-box}
body{
  margin:0;
  font-family:Inter, "Segoe UI", Roboto, Arial, sans-serif;
  background: linear-gradient(180deg, var(--bg) 0%, #070709 100%);
  color:#e8eef6;
  -webkit-font-smoothing:antialiased;
}
.container{
  max-width:1400px;
  margin:20px auto;
  padding:20px;
}
.header{
  display:flex;
  justify-content:space-between;
  align-items:center;
  margin-bottom:30px;
  padding-bottom:20px;
  border-bottom:1px solid rgba(255,255,255,0.1);
}
.header h1{
  font-size:28px;
  margin:0;
  color:#fff;
}
.header-stats{
  display:flex;
  gap:20px;
}
.stat-badge{
  background:rgba(255,255,255,0.05);
  padding:8px 16px;
  border-radius:8px;
  font-size:14px;
}
.stat-badge strong{
  color:var(--accent);
}
.alert{
  padding:12px 16px;
  border-radius:8px;
  margin-bottom:20px;
  font-size:14px;
}
.alert.success{
  background:rgba(16,185,129,0.1);
  color:#10b981;
  border:1px solid rgba(16,185,129,0.2);
}
.alert.error{
  background:rgba(239,68,68,0.1);
  color:#ef4444;
  border:1px solid rgba(239,68,68,0.2);
}
.grid{
  display:grid;
  grid-template-columns: 1fr 2fr;
  gap:20px;
  margin-bottom:30px;
}
.card{
  background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
  border:1px solid rgba(255,255,255,0.03);
  padding:20px;
  border-radius:12px;
}
.card-title{
  font-size:18px;
  font-weight:700;
  margin:0 0 16px 0;
  color:#fff;
}
.status-grid{
  display:grid;
  gap:12px;
}
.status-item{
  display:flex;
  justify-content:space-between;
  align-items:center;
  padding:12px;
  background:rgba(255,255,255,0.02);
  border-radius:8px;
  border-left:4px solid;
}
.status-item.ok{
  border-left-color:var(--success);
}
.status-item.ko{
  border-left-color:var(--error);
}
.status-item.warning{
  border-left-color:var(--warning);
}
.status-name{
  font-weight:600;
  margin-bottom:4px;
}
.status-details{
  font-size:12px;
  color:var(--muted);
}
.search-bar{
  display:flex;
  gap:12px;
  margin-bottom:20px;
}
.search-input{
  flex:1;
  padding:10px 16px;
  border:1px solid rgba(255,255,255,0.1);
  border-radius:8px;
  background:rgba(255,255,255,0.02);
  color:#fff;
  font-size:14px;
}
.search-input:focus{
  outline:none;
  border-color:var(--accent);
  background:rgba(255,255,255,0.04);
}
.btn{
  background:var(--accent);
  border:none;
  color:white;
  padding:10px 20px;
  border-radius:8px;
  font-weight:600;
  font-size:14px;
  cursor:pointer;
  transition:background 0.2s ease;
}
.btn:hover{
  background:var(--accent-2);
}
.users-table{
  width:100%;
  border-collapse:collapse;
  margin-top:16px;
}
.users-table th{
  background:rgba(255,255,255,0.05);
  padding:12px;
  text-align:left;
  font-weight:600;
  border-bottom:2px solid rgba(255,255,255,0.1);
}
.users-table td{
  padding:12px;
  border-bottom:1px solid rgba(255,255,255,0.05);
}
.users-table tr:hover{
  background:rgba(255,255,255,0.02);
}
.coins-cell{
  font-weight:700;
  color:var(--accent);
  font-size:16px;
}
.actions{
  display:flex;
  gap:8px;
}
.btn-small{
  padding:6px 12px;
  font-size:12px;
  border-radius:6px;
}
.btn-edit{
  background:var(--warning);
  color:var(--bg);
}
.btn-add{
  background:var(--success);
}
.pagination{
  display:flex;
  justify-content:center;
  gap:8px;
  margin-top:20px;
}
.page-link{
  padding:8px 12px;
  background:rgba(255,255,255,0.05);
  border-radius:6px;
  text-decoration:none;
  color:#fff;
  font-size:14px;
}
.page-link.active{
  background:var(--accent);
}
.modal{
  display:none;
  position:fixed;
  top:0;
  left:0;
  width:100%;
  height:100%;
  background:rgba(0,0,0,0.8);
  z-index:1000;
}
.modal-content{
  position:absolute;
  top:50%;
  left:50%;
  transform:translate(-50%, -50%);
  background:var(--card);
  padding:30px;
  border-radius:12px;
  width:400px;
  max-width:90%;
}
.modal-header{
  font-size:20px;
  font-weight:700;
  margin-bottom:20px;
  color:#fff;
}
.form-group{
  margin-bottom:16px;
}
.form-group label{
  display:block;
  margin-bottom:8px;
  font-weight:600;
  color:#e8eef6;
}
.form-group input{
  width:100%;
  padding:10px 12px;
  border:1px solid rgba(255,255,255,0.1);
  border-radius:6px;
  background:rgba(255,255,255,0.02);
  color:#fff;
  font-size:14px;
}
.modal-actions{
  display:flex;
  gap:12px;
  justify-content:flex-end;
  margin-top:20px;
}
@media(max-width:1024px){
  .grid{grid-template-columns:1fr}
}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>🔧 Administration Coins</h1>
    <div class="header-stats">
      <div class="stat-badge">
        <strong><?php echo $total_users; ?></strong> utilisateurs
      </div>
      <div class="stat-badge">
        <strong><?php echo count(array_filter($page_status, fn($p) => $p['exists'])); ?></strong>/<?php echo count($page_status); ?> pages OK
      </div>
    </div>
  </div>

  <?php if ($success_msg): ?>
    <div class="alert success"><?php echo htmlspecialchars($success_msg); ?></div>
  <?php endif; ?>

  <?php if ($error_msg): ?>
    <div class="alert error"><?php echo htmlspecialchars($error_msg); ?></div>
  <?php endif; ?>

  <div class="grid">
    <!-- Monitoring des pages -->
    <div class="card">
      <h2 class="card-title">📊 Monitoring des pages</h2>
      <div class="status-grid">
        <?php foreach ($page_status as $file => $status): ?>
        <div class="status-item <?php echo $status['exists'] ? 'ok' : 'ko'; ?>">
          <div>
            <div class="status-name"><?php echo htmlspecialchars($status['name']); ?></div>
            <div class="status-details"><?php echo htmlspecialchars($file); ?></div>
          </div>
          <div style="text-align:right">
            <div style="font-size:12px;color:<?php echo $status['exists'] ? 'var(--success)' : 'var(--error)'; ?>">
              <?php echo $status['exists'] ? '✓ OK' : '✗ Erreur'; ?>
            </div>
            <div style="font-size:10px;color:var(--muted)">
              <?php echo $status['modified']; ?>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Gestion des utilisateurs -->
    <div class="card">
      <h2 class="card-title">👥 Gestion des utilisateurs</h2>
      
      <div class="search-bar">
        <input type="text" class="search-input" name="search" placeholder="Rechercher par ID ou pseudo..." value="<?php echo htmlspecialchars($search); ?>">
        <button class="btn" onclick="window.location.search = new URLSearchParams(window.location.search).set('search', this.previousElementSibling.value)">🔍 Rechercher</button>
      </div>

      <table class="users-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Pseudo</th>
            <th>Email</th>
            <th>Coins</th>
            <th>Inscription</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($users as $user): ?>
          <tr>
            <td><?php echo $user['id']; ?></td>
            <td><?php echo htmlspecialchars($user['username']); ?></td>
            <td><?php echo htmlspecialchars($user['email']); ?></td>
            <td class="coins-cell"><?php echo number_format($user['coins']); ?> 💰</td>
            <td><?php echo date('d/m/Y', strtotime($user['created_at'])); ?></td>
            <td>
              <div class="actions">
                <button class="btn btn-small btn-edit" onclick="openEditModal(<?php echo $user['id']; ?>, <?php echo $user['coins']; ?>)">
                  ✏️ Modifier
                </button>
                <button class="btn btn-small btn-add" onclick="openAddModal(<?php echo $user['id']; ?>)">
                  ➕ Ajouter
                </button>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>

      <?php if ($total_pages > 1): ?>
      <div class="pagination">
        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
          <?php if ($i == $page): ?>
            <span class="page-link active"><?php echo $i; ?></span>
          <?php else: ?>
            <a href="?search=<?php echo urlencode($search); ?>&page=<?php echo $i; ?>" class="page-link"><?php echo $i; ?></a>
          <?php endif; ?>
        <?php endfor; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Modal pour modifier les coins -->
<div id="editModal" class="modal">
  <div class="modal-content">
    <div class="modal-header">✏️ Modifier les coins</div>
    <form method="POST">
      <input type="hidden" name="user_id" id="editUserId">
      <div class="form-group">
        <label>Nouveau montant de coins</label>
        <input type="number" name="new_coins" id="newCoins" min="0" required>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn" onclick="closeModal('editModal')" style="background:var(--muted)">Annuler</button>
        <button type="submit" name="update_coins" class="btn">Mettre à jour</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal pour ajouter des coins -->
<div id="addModal" class="modal">
  <div class="modal-content">
    <div class="modal-header">➕ Ajouter des coins</div>
    <form method="POST">
      <input type="hidden" name="user_id" id="addUserId">
      <div class="form-group">
        <label>Nombre de coins à ajouter</label>
        <input type="number" name="add_coins" id="addCoins" min="1" required>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn" onclick="closeModal('addModal')" style="background:var(--muted)">Annuler</button>
        <button type="submit" name="add_coins" class="btn">Ajouter</button>
      </div>
    </form>
  </div>
</div>

<script>
function openEditModal(userId, currentCoins) {
    document.getElementById('editUserId').value = userId;
    document.getElementById('newCoins').value = currentCoins;
    document.getElementById('editModal').style.display = 'block';
}

function openAddModal(userId) {
    document.getElementById('addUserId').value = userId;
    document.getElementById('addCoins').value = '';
    document.getElementById('addModal').style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Fermer les modals en cliquant à l'extérieur
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}
</script>
</body>
</html>
