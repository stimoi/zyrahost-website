<?php
/*
 coins--shop.php - Boutique de coins payants intelligents
 - Bundles temporaires avec offres limitées
 - Packs thématiques (débutant, boost, événement)
 - Système d'offres intelligentes
*/

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /login.php");
    exit;
}

// Paramètres DB
$db_host = 'localhost:3306';
$db_name = 'mttljx_zyrahostf_db';
$db_user = 'sti_moi';
$db_pass = 'pj32~lH36';

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8",
        $db_user,
        $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    die("Erreur de connexion à la base de données.");
}

$user_id = (int)$_SESSION['user_id'];

// Récupérer infos utilisateur
$stmt = $pdo->prepare("SELECT username, coins FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    session_destroy();
    header("Location: /login.php");
    exit;
}

$username = htmlspecialchars($user['username']);
$coins = (int)$user['coins'];

// Définir les bundles disponibles
$bundles = [
    'starter' => [
        'name' => 'Pack Débutant',
        'coins' => 500,
        'price' => '2.99€',
        'bonus' => '+50 coins bonus',
        'description' => 'Parfait pour démarrer',
        'color' => '#10b981'
    ],
    'boost' => [
        'name' => 'Pack Boost Serveur',
        'coins' => 1500,
        'price' => '7.99€',
        'bonus' => '+300 coins bonus',
        'description' => 'Optimise ton expérience',
        'color' => '#f59e0b'
    ],
    'event' => [
        'name' => 'Pack Événement Spécial',
        'coins' => 3000,
        'price' => '14.99€',
        'bonus' => '+750 coins bonus',
        'description' => 'Offre limitée !',
        'color' => '#ef4444'
    ],
    'premium' => [
        'name' => 'Pack VIP',
        'coins' => 10000,
        'price' => '39.99€',
        'bonus' => '+2500 coins bonus',
        'description' => 'Meilleur rapport qualité/prix',
        'color' => '#8b5cf6'
    ]
];

$message = "";
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['purchase_bundle'])) {
    $bundle_id = $_POST['bundle_id'] ?? '';
    
    if (isset($bundles[$bundle_id])) {
        $bundle = $bundles[$bundle_id];
        $total_coins = $bundle['coins'] + (int)filter_var($bundle['bonus'], FILTER_SANITIZE_NUMBER_INT);
        
        // Simuler le paiement (à intégrer avec Stripe/PayPal)
        $payment_success = true; // À remplacer par vraie vérification
        
        if ($payment_success) {
            // Ajouter les coins à l'utilisateur
            $stmt = $pdo->prepare("UPDATE users SET coins = coins + ? WHERE id = ?");
            $stmt->execute([$total_coins, $user_id]);
            
            // Enregistrer l'achat
            $stmt = $pdo->prepare("INSERT INTO coin_purchases (user_id, bundle_id, coins_received, price_paid) VALUES (?, ?, ?, ?)");
            $stmt->execute([$user_id, $bundle_id, $total_coins, $bundle['price']]);
            
            $coins += $total_coins;
            $success = true;
            $message = "✅ Achat réussi ! +{$total_coins} coins ajoutés à ton compte.";
        } else {
            $message = "❌ Échec du paiement. Réessaie ou contacte le support.";
        }
    }
}

// Créer la table si elle n'existe pas
$pdo->exec("CREATE TABLE IF NOT EXISTS coin_purchases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    bundle_id VARCHAR(20) NOT NULL,
    coins_received INT NOT NULL,
    price_paid VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (user_id)
)");
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Boutique Coins - ZyraHost</title>
<style>
:root{
  --bg:#0f0f12;
  --card:#121216;
  --muted:#9aa0a6;
  --accent:#5865F2;
  --accent-2:#6d7cff;
  --gold:#ffd700;
}
*{box-sizing:border-box}
body{
  margin:0;
  font-family:Inter, "Segoe UI", Roboto, Arial, sans-serif;
  background: linear-gradient(180deg, var(--bg) 0%, #070709 100%);
  color:#e8eef6;
  -webkit-font-smoothing:antialiased;
}
.container{
  max-width:1200px;
  margin:36px auto;
  padding:20px;
}
.header{
  text-align:center;
  margin-bottom:40px;
}
.logo{
  width:80px;
  height:80px;
  border-radius:16px;
  background:linear-gradient(135deg,var(--gold),#f59e0b);
  display:flex;
  align-items:center;
  justify-content:center;
  font-weight:700;
  color:white;
  font-size:32px;
  margin:0 auto 20px;
  box-shadow:0 8px 24px rgba(255,215,0,0.16);
}
h1{
  font-size:32px;
  margin:0;
  color:#fff;
}
.subtitle{
  color:var(--muted);
  font-size:16px;
  margin-top:12px;
}
.balance-display{
  background: linear-gradient(135deg, rgba(255,215,0,0.1), rgba(255,215,0,0.05));
  border:1px solid rgba(255,215,0,0.2);
  padding:20px;
  border-radius:16px;
  text-align:center;
  margin-bottom:40px;
}
.balance-amount{
  font-size:36px;
  font-weight:700;
  color:var(--gold);
  margin:0;
}
.bundles-grid{
  display:grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap:24px;
  margin-bottom:40px;
}
.bundle-card{
  background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
  border:1px solid rgba(255,255,255,0.03);
  padding:24px;
  border-radius:16px;
  text-align:center;
  position:relative;
  transition:transform 0.2s ease, box-shadow 0.2s ease;
}
.bundle-card:hover{
  transform:translateY(-4px);
  box-shadow: 0 12px 28px rgba(2,6,23,0.6);
}
.bundle-badge{
  position:absolute;
  top:-12px;
  right:16px;
  background:var(--gold);
  color:var(--bg);
  padding:6px 12px;
  border-radius:20px;
  font-size:12px;
  font-weight:700;
}
.bundle-header{
  margin-bottom:20px;
}
.bundle-title{
  font-size:20px;
  font-weight:700;
  margin:0 0 8px 0;
}
.bundle-description{
  color:var(--muted);
  font-size:14px;
}
.bundle-coins{
  font-size:32px;
  font-weight:700;
  color:var(--gold);
  margin:16px 0;
}
.bundle-bonus{
  background:rgba(16,185,129,0.1);
  color:#10b981;
  padding:6px 12px;
  border-radius:8px;
  font-size:14px;
  font-weight:600;
  margin-bottom:20px;
  display:inline-block;
}
.bundle-price{
  font-size:24px;
  font-weight:700;
  color:#fff;
  margin-bottom:20px;
}
.bundle-btn{
  width:100%;
  background:var(--accent);
  border:none;
  color:white;
  padding:12px 20px;
  border-radius:10px;
  font-weight:700;
  font-size:16px;
  cursor:pointer;
  transition:all 0.2s ease;
}
.bundle-btn:hover{
  background:var(--accent-2);
  transform:translateY(-1px);
}
.limited-offer{
  border-color:#ef4444;
  animation:pulse 2s infinite;
}
@keyframes pulse{
  0%,100%{box-shadow:0 0 0 0 rgba(239,68,68,0.4)}
  50%{box-shadow:0 0 0 8px rgba(239,68,68,0)}
}
.status{
  padding:12px 16px;
  border-radius:10px;
  font-size:14px;
  margin-bottom:20px;
  text-align:center;
}
.status.success{background:rgba(16,185,129,0.08);color:#8ef0b8;border:1px solid rgba(16,185,129,0.08)}
.status.error{background:rgba(255,99,71,0.06);color:#ffb3aa;border:1px solid rgba(255,99,71,0.04)}
.back-link{
  text-align:center;
  margin-top:20px;
}
.back-link a{
  color:var(--muted);
  text-decoration:none;
  font-size:13px;
}
.back-link a:hover{
  color:var(--accent);
}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="logo">💎</div>
    <h1>Boutique Coins</h1>
    <div class="subtitle">Des offres intelligentes pour booster ton expérience</div>
  </div>

  <div class="balance-display">
    <div class="balance-amount"><?php echo number_format($coins); ?> coins</div>
    <div style="color:var(--muted);margin-top:8px">Solde actuel</div>
  </div>

  <?php if ($message): ?>
    <div class="status <?php echo $success ? 'success' : 'error'; ?>">
      <?php echo htmlspecialchars($message); ?>
    </div>
  <?php endif; ?>

  <div class="bundles-grid">
    <?php foreach ($bundles as $bundle_id => $bundle): ?>
    <div class="bundle-card <?php echo $bundle_id === 'event' ? 'limited-offer' : ''; ?>">
      <?php if ($bundle_id === 'event'): ?>
      <div class="bundle-badge">LIMITÉ</div>
      <?php endif; ?>
      
      <div class="bundle-header">
        <div class="bundle-title" style="color:<?php echo $bundle['color']; ?>">
          <?php echo htmlspecialchars($bundle['name']); ?>
        </div>
        <div class="bundle-description">
          <?php echo htmlspecialchars($bundle['description']); ?>
        </div>
      </div>

      <div class="bundle-coins">
        <?php echo number_format($bundle['coins']); ?> 💰
      </div>

      <div class="bundle-bonus">
        <?php echo htmlspecialchars($bundle['bonus']); ?>
      </div>

      <div class="bundle-price">
        <?php echo htmlspecialchars($bundle['price']); ?>
      </div>

      <form method="POST">
        <input type="hidden" name="bundle_id" value="<?php echo $bundle_id; ?>">
        <button type="submit" name="purchase_bundle" class="bundle-btn">
          Acheter maintenant
        </button>
      </form>
    </div>
    <?php endforeach; ?>
  </div>

  <div style="background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.03);padding:20px;border-radius:12px;margin-bottom:20px">
    <h3 style="margin:0 0 12px 0;color:var(--accent)">💡 Pourquoi acheter des coins ?</h3>
    <ul style="margin:0;padding-left:20px;color:var(--muted);font-size:14px">
      <li>Accès rapide aux fonctionnalités premium</li>
      <li>Soutien au développement de ZyraHost</li>
      <li>Offres exclusives et bonus temporaires</li>
      <li>Économise de temps par rapport aux méthodes gratuites</li>
    </ul>
  </div>

  <div class="back-link">
    <a href="/coins/coins.php">← Retour aux coins</a>
  </div>
</div>
</body>
</html>
