<?php
/*
 coins--premium.php - Avantages premium non pay-to-win
 - Affiche les avantages premium disponibles
 - Permet d'acheter avec des coins
 - Non pay-to-win : avantages de confort uniquement
*/

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /login.php");
    exit;
}

// Paramètres DB
$db_host = 'localhost:3306';
$db_name = 'mttljx_zyrahostf_db';
$db_user = 'sti_moi';
$db_pass = 'pj32~lH36';

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8",
        $db_user,
        $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    die("Erreur de connexion à la base de données.");
}

$user_id = (int)$_SESSION['user_id'];

// Récupérer infos utilisateur
try {
    $stmt = $pdo->prepare("SELECT username, coins, premium_until FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Si la colonne premium_until n'existe pas, on récupère juste username et coins
    try {
        $stmt = $pdo->prepare("SELECT username, coins FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        $user['premium_until'] = null;
    } catch (Exception $e2) {
        die("Erreur lors de la récupération des données utilisateur.");
    }
}

if (!$user) {
    session_destroy();
    header("Location: /login.php");
    exit;
}

$username = htmlspecialchars($user['username']);
$coins = (int)$user['coins'];
$premium_until = $user['premium_until'];
$is_premium = !empty($premium_until) && strtotime($premium_until) > time();

$message = "";
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['purchase_premium'])) {
    $duration = $_POST['duration'] ?? '';
    $prices = [
        '7_days' => 500,
        '30_days' => 1500,
        '90_days' => 3500,
        '365_days' => 10000
    ];
    
    if (isset($prices[$duration])) {
        $cost = $prices[$duration];
        
        if ($coins >= $cost) {
            // Calculer la nouvelle date d'expiration
            $current_expiry = $is_premium ? strtotime($premium_until) : time();
            $new_expiry = $current_expiry + ($duration === '7_days' ? 7*24*3600 : 
                                              ($duration === '30_days' ? 30*24*3600 : 
                                               ($duration === '90_days' ? 90*24*3600 : 365*24*3600)));
            
            // Mettre à jour l'utilisateur
            $stmt = $pdo->prepare("UPDATE users SET coins = coins - ?, premium_until = ? WHERE id = ?");
            $stmt->execute([$cost, date('Y-m-d H:i:s', $new_expiry), $user_id]);
            
            // Enregistrer l'achat
            $stmt = $pdo->prepare("INSERT INTO premium_purchases (user_id, duration, cost, old_expiry, new_expiry) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$user_id, $duration, $cost, $premium_until, date('Y-m-d H:i:s', $new_expiry)]);
            
            $coins -= $cost;
            $premium_until = date('Y-m-d H:i:s', $new_expiry);
            $is_premium = true;
            $success = true;
            $message = "✅ Premium acheté avec succès ! Tu es maintenant premium jusqu'au " . date('d/m/Y H:i', $new_expiry);
        } else {
            $message = "❌ Coins insuffisants. Il te manque " . ($cost - $coins) . " coins.";
        }
    }
}

// Créer les tables si elles n'existent pas
$pdo->exec("CREATE TABLE IF NOT EXISTS premium_purchases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    duration VARCHAR(20) NOT NULL,
    cost INT NOT NULL,
    old_expiry TIMESTAMP NULL,
    new_expiry TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (user_id)
)");
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Premium - ZyraHost</title>
<style>
:root{
  --bg:#0f0f12;
  --card:#121216;
  --muted:#9aa0a6;
  --accent:#5865F2;
  --accent-2:#6d7cff;
  --gold:#ffd700;
  --premium:#8b5cf6;
  --premium-dark:#7c3aed;
}
*{box-sizing:border-box}
body{
  margin:0;
  font-family:Inter, "Segoe UI", Roboto, Arial, sans-serif;
  background: linear-gradient(180deg, var(--bg) 0%, #070709 100%);
  color:#e8eef6;
  -webkit-font-smoothing:antialiased;
}
.container{
  max-width:1000px;
  margin:36px auto;
  padding:20px;
}
.header{
  text-align:center;
  margin-bottom:40px;
}
.logo{
  width:80px;
  height:80px;
  border-radius:16px;
  background:linear-gradient(135deg,var(--premium),var(--premium-dark));
  display:flex;
  align-items:center;
  justify-content:center;
  font-weight:700;
  color:white;
  font-size:32px;
  margin:0 auto 20px;
  box-shadow:0 8px 24px rgba(139,92,246,0.16);
}
h1{
  font-size:32px;
  margin:0;
  color:#fff;
}
.subtitle{
  color:var(--muted);
  font-size:16px;
  margin-top:12px;
}
.status-card{
  background: linear-gradient(135deg, rgba(139,92,246,0.1), rgba(139,92,246,0.05));
  border:1px solid rgba(139,92,246,0.2);
  padding:24px;
  border-radius:16px;
  text-align:center;
  margin-bottom:40px;
}
.status-badge{
  display:inline-block;
  background:var(--premium);
  color:white;
  padding:8px 16px;
  border-radius:20px;
  font-weight:600;
  font-size:14px;
  margin-bottom:12px;
}
.status-text{
  font-size:18px;
  margin:0;
}
.benefits-grid{
  display:grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap:20px;
  margin-bottom:40px;
}
.benefit-card{
  background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
  border:1px solid rgba(255,255,255,0.03);
  padding:20px;
  border-radius:12px;
  text-align:center;
}
.benefit-icon{
  font-size:32px;
  margin-bottom:12px;
}
.benefit-title{
  font-size:16px;
  font-weight:700;
  margin:0 0 8px 0;
  color:#fff;
}
.benefit-description{
  color:var(--muted);
  font-size:14px;
  line-height:1.4;
}
.pricing-section{
  background:rgba(255,255,255,0.02);
  border:1px solid rgba(255,255,255,0.03);
  padding:30px;
  border-radius:16px;
  margin-bottom:40px;
}
.pricing-title{
  font-size:24px;
  font-weight:700;
  margin:0 0 24px 0;
  text-align:center;
}
.pricing-grid{
  display:grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap:16px;
  margin-bottom:24px;
}
.price-card{
  background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
  border:1px solid rgba(255,255,255,0.03);
  padding:20px;
  border-radius:12px;
  text-align:center;
  transition:transform 0.2s ease, box-shadow 0.2s ease;
}
.price-card:hover{
  transform:translateY(-2px);
  box-shadow: 0 8px 20px rgba(2,6,23,0.4);
}
.price-card.popular{
  border-color:var(--premium);
  position:relative;
}
.price-card.popular::before{
  content:'POPULAIRE';
  position:absolute;
  top:-12px;
  left:50%;
  transform:translateX(-50%);
  background:var(--premium);
  color:white;
  padding:4px 12px;
  border-radius:12px;
  font-size:11px;
  font-weight:700;
}
.price-duration{
  font-size:14px;
  color:var(--muted);
  margin-bottom:8px;
}
.price-amount{
  font-size:28px;
  font-weight:700;
  color:var(--gold);
  margin:0 0 16px 0;
}
.price-btn{
  width:100%;
  background:var(--premium);
  border:none;
  color:white;
  padding:10px 16px;
  border-radius:8px;
  font-weight:600;
  font-size:14px;
  cursor:pointer;
  transition:background 0.2s ease;
}
.price-btn:hover{
  background:var(--premium-dark);
}
.price-btn:disabled{
  opacity:.5;
  cursor:not-allowed;
}
.status{
  padding:12px 16px;
  border-radius:10px;
  font-size:14px;
  margin-bottom:20px;
  text-align:center;
}
.status.success{background:rgba(16,185,129,0.08);color:#8ef0b8;border:1px solid rgba(16,185,129,0.08)}
.status.error{background:rgba(255,99,71,0.06);color:#ffb3aa;border:1px solid rgba(255,99,71,0.04)}
.back-link{
  text-align:center;
  margin-top:20px;
}
.back-link a{
  color:var(--muted);
  text-decoration:none;
  font-size:13px;
}
.back-link a:hover{
  color:var(--accent);
}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="logo">⭐</div>
    <h1>Avantages Premium</h1>
    <div class="subtitle">Gagne en confort sans devenir pay-to-win</div>
  </div>

  <div class="status-card">
    <div class="status-badge">
      <?php echo $is_premium ? 'PREMIUM ACTIF' : 'GRATUIT'; ?>
    </div>
    <div class="status-text">
      <?php 
      if ($is_premium) {
          echo "Premium jusqu'au " . date('d/m/Y H:i', strtotime($premium_until));
      } else {
          echo "Passe premium pour débloquer des avantages exclusifs";
      }
      ?>
    </div>
  </div>

  <?php if ($message): ?>
    <div class="status <?php echo $success ? 'success' : 'error'; ?>">
      <?php echo htmlspecialchars($message); ?>
    </div>
  <?php endif; ?>

  <div class="benefits-grid">
    <div class="benefit-card">
      <div class="benefit-icon">🚫</div>
      <div class="benefit-title">Suppression des pubs</div>
      <div class="benefit-description">
        Plus aucune publicité pour gagner des coins. Expérience 100% propre.
      </div>
    </div>

    <div class="benefit-card">
      <div class="benefit-icon">⚡</div>
      <div class="benefit-title">Démarrage rapide</div>
      <div class="benefit-description">
        Tes serveurs démarrent 2x plus vite. Moins d'attente, plus de gaming.
      </div>
    </div>

    <div class="benefit-card">
      <div class="benefit-icon">💾</div>
      <div class="benefit-title">Backups fréquents</div>
      <div class="benefit-description">
        Sauvegardes toutes les 6h au lieu de 24h. Protège ton travail mieux.
      </div>
    </div>

    <div class="benefit-card">
      <div class="benefit-icon">🎧</div>
      <div class="benefit-title">Support prioritaire</div>
      <div class="benefit-description">
        Réponses sous 2h au lieu de 24h. Assistance VIP quand t'en as besoin.
      </div>
    </div>

    <div class="benefit-card">
      <div class="benefit-icon">🔥</div>
      <div class="benefit-title">Bêta features</div>
      <div class="benefit-description">
        Accès anticipé aux nouvelles fonctionnalités. Sois le premier à tester.
      </div>
    </div>

    <div class="benefit-card">
      <div class="benefit-icon">🎨</div>
      <div class="benefit-title">Custom branding</div>
      <div class="benefit-description">
        Retire le logo ZyraHost. Interface plus épurée et personnalisée.
      </div>
    </div>
  </div>

  <?php if (!$is_premium): ?>
  <div class="pricing-section">
    <div class="pricing-title">Choisis ta durée</div>
    <form method="POST">
      <div class="pricing-grid">
        <div class="price-card">
          <div class="price-duration">7 jours</div>
          <div class="price-amount">500 💰</div>
          <button type="submit" name="purchase_premium" value="7_days" class="price-btn" 
                  <?php echo $coins < 500 ? 'disabled' : ''; ?>>
            <?php echo $coins < 500 ? 'Coins insuffisants' : 'Acheter'; ?>
          </button>
        </div>

        <div class="price-card">
          <div class="price-duration">30 jours</div>
          <div class="price-amount">1 500 💰</div>
          <button type="submit" name="purchase_premium" value="30_days" class="price-btn"
                  <?php echo $coins < 1500 ? 'disabled' : ''; ?>>
            <?php echo $coins < 1500 ? 'Coins insuffisants' : 'Acheter'; ?>
          </button>
        </div>

        <div class="price-card popular">
          <div class="price-duration">90 jours</div>
          <div class="price-amount">3 500 💰</div>
          <button type="submit" name="purchase_premium" value="90_days" class="price-btn"
                  <?php echo $coins < 3500 ? 'disabled' : ''; ?>>
            <?php echo $coins < 3500 ? 'Coins insuffisants' : 'Acheter'; ?>
          </button>
        </div>

        <div class="price-card">
          <div class="price-duration">365 jours</div>
          <div class="price-amount">10 000 💰</div>
          <button type="submit" name="purchase_premium" value="365_days" class="price-btn"
                  <?php echo $coins < 10000 ? 'disabled' : ''; ?>>
            <?php echo $coins < 10000 ? 'Coins insuffisants' : 'Acheter'; ?>
          </button>
        </div>
      </div>
    </form>
  </div>
  <?php endif; ?>

  <div class="back-link">
    <a href="/coins/coins.php">← Retour aux coins</a>
  </div>
</div>
</body>
</html>
