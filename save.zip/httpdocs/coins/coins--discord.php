<?php
/*
 discord-status.php - Vérification du statut Discord
 - Vérifie si l'utilisateur a le statut requis
 - Donne une récompense une fois par jour
*/

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /login.php");
    exit;
}

// Paramètres DB
$db_host = 'localhost:3306';
$db_name = 'mttljx_zyrahostf_db';
$db_user = 'sti_moi';
$db_pass = 'pj32~lH36';

$reward_value = 5; // coins pour statut Discord
$required_status = "zyrahost.fr | host bots gratuit";
$cooldown_hours = 24; // une fois par jour

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8",
        $db_user,
        $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    die("Erreur de connexion à la base de données.");
}

$user_id = (int)$_SESSION['user_id'];

// Vérifier si l'utilisateur a déjà reçu la récompense aujourd'hui (simplifié avec session)
$session_key = 'coins_' . date('Y-m-d');
if (!isset($_SESSION[$session_key])) {
    $_SESSION[$session_key] = ['ads' => 0, 'discord' => 0, 'daily' => 0];
}
$already_rewarded = $_SESSION[$session_key]['discord'] > 0;

// Récupérer infos utilisateur
$stmt = $pdo->prepare("SELECT username, coins FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    session_destroy();
    header("Location: /login.php");
    exit;
}

$username = htmlspecialchars($user['username']);
$coins = (int)$user['coins'];

$message = "";
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['check_status'])) {
    if (!$already_rewarded) {
        // Simuler la vérification du statut Discord
        $discord_user_id = $_POST['discord_user_id'] ?? '';
        
        if (!empty($discord_user_id)) {
            // Pour l'instant, on donne la récompense automatiquement
            $stmt = $pdo->prepare("UPDATE users SET coins = coins + ? WHERE id = ?");
            $stmt->execute([$reward_value, $user_id]);
            
            // Mettre à jour la session
            $_SESSION[$session_key]['discord'] = 1;
            
            $coins += $reward_value;
            $already_rewarded = true;
            $success = true;
            $message = "✅ Statut vérifié ! +{$reward_value} coins ajoutés.";
        } else {
            $message = "❌ Veuillez entrer votre ID Discord.";
        }
    } else {
        $message = "⏰ Tu as déjà reçu ta récompense aujourd'hui. Reviens demain !";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Statut Discord - ZyraHost</title>
<style>
:root{
  --bg:#0f0f12;
  --card:#121216;
  --muted:#9aa0a6;
  --accent:#5865F2;
  --accent-2:#6d7cff;
  --gold:#ffd700;
}
*{box-sizing:border-box}
body{
  margin:0;
  font-family:Inter, "Segoe UI", Roboto, Arial, sans-serif;
  background: linear-gradient(180deg, var(--bg) 0%, #070709 100%);
  color:#e8eef6;
  -webkit-font-smoothing:antialiased;
}
.container{
  max-width:600px;
  margin:36px auto;
  padding:20px;
}
.card{
  background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
  border:1px solid rgba(255,255,255,0.03);
  padding:30px;
  border-radius:14px;
  box-shadow: 0 6px 22px rgba(2,6,23,0.5);
}
.header{
  text-align:center;
  margin-bottom:30px;
}
.logo{
  width:64px;
  height:64px;
  border-radius:12px;
  background:linear-gradient(135deg,var(--accent),var(--accent-2));
  display:flex;
  align-items:center;
  justify-content:center;
  font-weight:700;
  color:white;
  font-size:24px;
  margin:0 auto 16px;
  box-shadow:0 6px 18px rgba(88,101,242,0.14);
}
h1{
  font-size:24px;
  margin:0;
  color:#fff;
}
.subtitle{
  color:var(--muted);
  font-size:14px;
  margin-top:8px;
}
.form-group{
  margin-bottom:20px;
}
label{
  display:block;
  margin-bottom:8px;
  font-weight:600;
  color:#e8eef6;
}
input{
  width:100%;
  padding:12px 16px;
  border:1px solid rgba(255,255,255,0.1);
  border-radius:8px;
  background:rgba(255,255,255,0.02);
  color:#fff;
  font-size:14px;
  transition:border-color 0.2s;
}
input:focus{
  outline:none;
  border-color:var(--accent);
  background:rgba(255,255,255,0.04);
}
.btn{
  width:100%;
  background:var(--accent);
  border:none;
  color:white;
  padding:14px 20px;
  border-radius:10px;
  font-weight:700;
  font-size:16px;
  cursor:pointer;
  transition:transform 0.12s ease, box-shadow 0.12s;
  box-shadow: 0 8px 20px rgba(88,101,242,0.12);
}
.btn:active{transform:translateY(1px)}
.btn:disabled{
  opacity:.5;
  cursor:not-allowed;
  transform:none;
  box-shadow:none;
}
.status{
  padding:12px 16px;
  border-radius:10px;
  font-size:14px;
  margin-bottom:20px;
  text-align:center;
}
.status.success{background:rgba(16,185,129,0.08);color:#8ef0b8;border:1px solid rgba(16,185,129,0.08)}
.status.error{background:rgba(255,99,71,0.06);color:#ffb3aa;border:1px solid rgba(255,99,71,0.04)}
.requirements{
  background:rgba(255,255,255,0.02);
  padding:16px;
  border-radius:8px;
  margin-bottom:20px;
}
.requirements h3{
  margin:0 0 12px 0;
  font-size:16px;
  color:var(--accent);
}
.requirements ul{
  margin:0;
  padding-left:20px;
  color:var(--muted);
  font-size:14px;
}
.requirements li{
  margin-bottom:8px;
}
.back-link{
  text-align:center;
  margin-top:20px;
}
.back-link a{
  color:var(--muted);
  text-decoration:none;
  font-size:13px;
}
.back-link a:hover{
  color:var(--accent);
}
</style>
</head>
<body>
<div class="container">
  <div class="card">
    <div class="header">
      <div class="logo">D</div>
      <h1>Statut Discord</h1>
      <div class="subtitle">Gagne des coins en affichant un statut Discord</div>
    </div>

    <?php if ($message): ?>
      <div class="status <?php echo $success ? 'success' : 'error'; ?>">
        <?php echo htmlspecialchars($message); ?>
      </div>
    <?php endif; ?>

    <div class="requirements">
      <h3>📋 Conditions requises</h3>
      <ul>
        <li>Ajoute le statut : <strong>"<?php echo htmlspecialchars($required_status); ?>"</strong></li>
        <li>Garde-le pendant au moins 1 heure</li>
        <li>Récompense : <strong><?php echo $reward_value; ?> coins</strong></li>
        <li>Disponible une fois par jour</li>
      </ul>
    </div>

    <form method="POST">
      <div class="form-group">
        <label for="discord_user_id">Ton ID Discord</label>
        <input type="text" id="discord_user_id" name="discord_user_id" 
               placeholder="Ex: 123456789012345678" required>
      </div>
      
      <button type="submit" name="check_status" class="btn" 
              <?php echo $already_rewarded ? 'disabled' : ''; ?>>
        <?php echo $already_rewarded ? '⏰ Récompense déjà reçue aujourd\'hui' : '🎯 Vérifier mon statut (+5 coins)'; ?>
      </button>
    </form>

    <div class="back-link">
      <a href="/coins/coins.php">← Retour aux coins</a>
    </div>
  </div>
</div>
</body>
</html>
