<?php
/*
 coins--referral.php - Système de parrainage
 - Génère des liens de parrainage
 - Suit les parrainages et les récompenses
 - Bonus supplémentaires si l'ami devient actif ou premium
*/

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /login.php");
    exit;
}

// Paramètres DB
$db_host = 'localhost:3306';
$db_name = 'mttljx_zyrahostf_db';
$db_user = 'sti_moi';
$db_pass = 'pj32~lH36';

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8",
        $db_user,
        $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    die("Erreur de connexion à la base de données.");
}

$user_id = (int)$_SESSION['user_id'];

// Récupérer infos utilisateur
$stmt = $pdo->prepare("SELECT username, coins FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    session_destroy();
    header("Location: /login.php");
    exit;
}

$username = htmlspecialchars($user['username']);
$coins = (int)$user['coins'];

// Générer un code de parrainage si l'utilisateur n'en a pas (simplifié)
$referral_code = strtoupper(substr(md5($user_id . time()), 0, 8));
$referral_link = "https://zyrahost.fr/register?ref=" . $referral_code;

// Statistiques de parrainage (simplifiées avec session)
$session_key = 'coins_' . date('Y-m-d');
if (!isset($_SESSION[$session_key])) {
    $_SESSION[$session_key] = ['ads' => 0, 'discord' => 0, 'daily' => 0];
}

// Simuler des statistiques (à remplacer par vraies données)
$total_referrals = 0; // À récupérer depuis une table si nécessaire
$total_earned = 0; // À calculer depuis les logs si nécessaire

// Simuler quelques parrainages pour démo
$referrals = [
    ['username' => 'AmiDemo1', 'created_at' => date('Y-m-d H:i:s', strtotime('-5 days')), 'premium' => false],
    ['username' => 'AmiDemo2', 'created_at' => date('Y-m-d H:i:s', strtotime('-2 days')), 'premium' => true],
];

$message = "";
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['copy_link'])) {
    $success = true;
    $message = "✅ Lien de parrainage copié dans le presse-papiers !";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Parrainage - ZyraHost</title>
<style>
:root{
  --bg:#0f0f12;
  --card:#121216;
  --muted:#9aa0a6;
  --accent:#5865F2;
  --accent-2:#6d7cff;
  --gold:#ffd700;
  --success:#10b981;
  --referral:#06b6d4;
}
*{box-sizing:border-box}
body{
  margin:0;
  font-family:Inter, "Segoe UI", Roboto, Arial, sans-serif;
  background: linear-gradient(180deg, var(--bg) 0%, #070709 100%);
  color:#e8eef6;
  -webkit-font-smoothing:antialiased;
}
.container{
  max-width:1000px;
  margin:36px auto;
  padding:20px;
}
.header{
  text-align:center;
  margin-bottom:40px;
}
.logo{
  width:80px;
  height:80px;
  border-radius:16px;
  background:linear-gradient(135deg,var(--referral),#0891b2);
  display:flex;
  align-items:center;
  justify-content:center;
  font-weight:700;
  color:white;
  font-size:32px;
  margin:0 auto 20px;
  box-shadow:0 8px 24px rgba(6,182,212,0.16);
}
h1{
  font-size:32px;
  margin:0;
  color:#fff;
}
.subtitle{
  color:var(--muted);
  font-size:16px;
  margin-top:12px;
}
.referral-card{
  background: linear-gradient(135deg, rgba(6,182,212,0.1), rgba(6,182,212,0.05));
  border:1px solid rgba(6,182,212,0.2);
  padding:24px;
  border-radius:16px;
  text-align:center;
  margin-bottom:40px;
}
.referral-code{
  font-size:24px;
  font-weight:700;
  color:var(--referral);
  margin:16px 0;
  font-family:monospace;
}
.referral-link{
  background:rgba(255,255,255,0.05);
  border:1px solid rgba(255,255,255,0.1);
  padding:12px 16px;
  border-radius:8px;
  font-family:monospace;
  font-size:14px;
  word-break:break-all;
  margin:16px 0;
}
.copy-btn{
  background:var(--referral);
  border:none;
  color:white;
  padding:10px 20px;
  border-radius:8px;
  font-weight:600;
  cursor:pointer;
  transition:background 0.2s ease;
}
.copy-btn:hover{
  background:#0891b2;
}
.stats-grid{
  display:grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap:20px;
  margin-bottom:40px;
}
.stat-card{
  background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
  border:1px solid rgba(255,255,255,0.03);
  padding:20px;
  border-radius:12px;
  text-align:center;
}
.stat-value{
  font-size:28px;
  font-weight:700;
  color:var(--gold);
  margin:0;
}
.stat-label{
  color:var(--muted);
  font-size:14px;
  margin-top:8px;
}
.rewards-section{
  background:rgba(255,255,255,0.02);
  border:1px solid rgba(255,255,255,0.03);
  padding:24px;
  border-radius:16px;
  margin-bottom:40px;
}
.rewards-title{
  font-size:20px;
  font-weight:700;
  margin:0 0 20px 0;
  color:var(--accent);
}
.rewards-grid{
  display:grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap:16px;
}
.reward-item{
  background:rgba(255,255,255,0.02);
  padding:16px;
  border-radius:8px;
  border-left:4px solid var(--success);
}
.reward-amount{
  font-size:18px;
  font-weight:700;
  color:var(--gold);
  margin:0 0 8px 0;
}
.reward-condition{
  color:var(--muted);
  font-size:14px;
  margin:0;
}
.referrals-list{
  background:rgba(255,255,255,0.02);
  border:1px solid rgba(255,255,255,0.03);
  padding:24px;
  border-radius:16px;
  margin-bottom:40px;
}
.referrals-title{
  font-size:20px;
  font-weight:700;
  margin:0 0 20px 0;
}
.referral-item{
  display:flex;
  justify-content:space-between;
  align-items:center;
  padding:12px 0;
  border-bottom:1px solid rgba(255,255,255,0.05);
}
.referral-item:last-child{
  border-bottom:none;
}
.referral-info{
  flex:1;
}
.referral-username{
  font-weight:600;
  margin-bottom:4px;
}
.referral-date{
  color:var(--muted);
  font-size:13px;
}
.referral-status{
  text-align:right;
}
.status-badge{
  display:inline-block;
  padding:4px 8px;
  border-radius:12px;
  font-size:12px;
  font-weight:600;
}
.status-badge.active{
  background:rgba(16,185,129,0.1);
  color:#10b981;
}
.status-badge.premium{
  background:rgba(139,92,246,0.1);
  color:#8b5cf6;
}
.status-badge.pending{
  background:rgba(245,158,11,0.1);
  color:#f59e0b;
}
.status{
  padding:12px 16px;
  border-radius:10px;
  font-size:14px;
  margin-bottom:20px;
  text-align:center;
}
.status.success{background:rgba(16,185,129,0.08);color:#8ef0b8;border:1px solid rgba(16,185,129,0.08)}
.back-link{
  text-align:center;
  margin-top:20px;
}
.back-link a{
  color:var(--muted);
  text-decoration:none;
  font-size:13px;
}
.back-link a:hover{
  color:var(--accent);
}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="logo">👥</div>
    <h1>Parrainage</h1>
    <div class="subtitle">Invite tes amis et gagne des coins ensemble</div>
  </div>

  <?php if ($message): ?>
    <div class="status <?php echo $success ? 'success' : 'error'; ?>">
      <?php echo htmlspecialchars($message); ?>
    </div>
  <?php endif; ?>

  <div class="referral-card">
    <div style="font-size:18px;font-weight:700;margin-bottom:16px">Ton lien de parrainage</div>
    <div class="referral-code"><?php echo htmlspecialchars($referral_code); ?></div>
    <div class="referral-link"><?php echo htmlspecialchars($referral_link); ?></div>
    <form method="POST" style="margin-top:16px">
      <button type="submit" name="copy_link" class="copy-btn" onclick="navigator.clipboard.writeText('<?php echo htmlspecialchars($referral_link); ?>')">
        📋 Copier le lien
      </button>
    </form>
  </div>

  <div class="stats-grid">
    <div class="stat-card">
      <div class="stat-value"><?php echo $total_referrals; ?></div>
      <div class="stat-label">Amis parrainés</div>
    </div>
    <div class="stat-card">
      <div class="stat-value"><?php echo number_format($total_earned); ?></div>
      <div class="stat-label">Coins gagnés</div>
    </div>
    <div class="stat-card">
      <div class="stat-value"><?php echo $total_referrals * 100; ?></div>
      <div class="stat-label">Coins potentiels</div>
    </div>
  </div>

  <div class="rewards-section">
    <div class="rewards-title">🎯 Récompenses de parrainage</div>
    <div class="rewards-grid">
      <div class="reward-item">
        <div class="reward-amount">+50 coins</div>
        <div class="reward-condition">Quand un ami crée un compte avec ton lien</div>
      </div>
      <div class="reward-item">
        <div class="reward-amount">+100 coins</div>
        <div class="reward-condition">Quand ton ami devient actif (10+ actions)</div>
      </div>
      <div class="reward-item">
        <div class="reward-amount">+200 coins</div>
        <div class="reward-condition">Quand ton ami passe premium</div>
      </div>
      <div class="reward-item">
        <div class="reward-amount">+25 coins</div>
        <div class="reward-condition">Bonus pour ton ami à l'inscription</div>
      </div>
    </div>
  </div>

  <?php if (!empty($referrals)): ?>
  <div class="referrals-list">
    <div class="referrals-title">📋 Tes parrainages</div>
    <?php foreach ($referrals as $referral): ?>
    <div class="referral-item">
      <div class="referral-info">
        <div class="referral-username"><?php echo htmlspecialchars($referral['username']); ?></div>
        <div class="referral-date">Inscrit le <?php echo date('d/m/Y', strtotime($referral['created_at'])); ?></div>
      </div>
      <div class="referral-status">
        <?php
        $is_premium = $referral['premium'] ?? false;
        $is_active = true; // Simplifié
        
        if ($is_premium) {
            echo '<span class="status-badge premium">PREMIUM</span>';
        } elseif ($is_active) {
            echo '<span class="status-badge active">ACTIF</span>';
        } else {
            echo '<span class="status-badge pending">NOUVEAU</span>';
        }
        ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <div style="background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.03);padding:20px;border-radius:12px;margin-bottom:20px">
    <h3 style="margin:0 0 12px 0;color:var(--referral)">💡 Comment ça marche ?</h3>
    <ol style="margin:0;padding-left:20px;color:var(--muted);font-size:14px">
      <li>Partage ton lien de parrainage avec tes amis</li>
      <li>Ils s'inscrivent avec ton lien et reçoivent 25 coins bonus</li>
      <li>Tu reçois 50 coins dès leur inscription</li>
      <li>Gagne des bonus supplémentaires quand ils deviennent actifs ou premium</li>
    </ol>
  </div>

  <div class="back-link">
    <a href="/coins/coins.php">← Retour aux coins</a>
  </div>
</div>
</body>
</html>
