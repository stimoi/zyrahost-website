<?php
session_start();

/*
 coins.php - page principale des coins
 - affiche le nombre de coins
 - affiche progression journalière (ex 3/10)
 - affiche récompense (+1 coin)
 - bouton pour lancer une pub (appelle /api/coins.php)
 - affiche messages de statut (success / limit / erreur)
*/

// Vérifier que l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: /login.php");
    exit;
}

// ======= Paramètres DB (vérifie / modifie si besoin) =======
$db_host = 'localhost:3306';
$db_name = 'mttljx_zyrahostf_db';
$db_user = 'sti_moi';
$db_pass = 'pj32~lH36';

// Valeur de la récompense
$reward_value = 10; // coins gagnés par pub

// Limite quotidienne
$max_ads_per_day = 10;

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8",
        $db_user,
        $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    // Affiche une page simple d'erreur (éviter d'exposer $e->getMessage en prod)
    die("Erreur de connexion à la base de données. Contacte l'administrateur.");
}

$user_id = (int)$_SESSION['user_id'];

// Récupérer infos utilisateur (username, coins)
$stmt = $pdo->prepare("SELECT id, username, coins FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    // Si l'utilisateur n'existe pas, déconnecter
    session_destroy();
    header("Location: /login.php");
    exit;
}

$username = htmlspecialchars($user['username']);
$coins = (int)$user['coins'];

// Compter le nombre de pubs vues aujourd'hui (simplifié avec session)
$session_key = 'coins_' . date('Y-m-d');
if (!isset($_SESSION[$session_key])) {
    $_SESSION[$session_key] = ['ads' => 0, 'discord' => 0, 'daily' => 0];
}
$ads_today = $_SESSION[$session_key]['ads'];

// Calculs pour l'UI
$remaining = max(0, $max_ads_per_day - $ads_today);
$progress_percent = ($max_ads_per_day > 0) ? round(($ads_today / $max_ads_per_day) * 100) : 0;

// Messages de statut (optionnels via query string)
$status_msg = null;
$status_type = null;
if (isset($_GET['success'])) {
    $status_msg = "🎉 Pub terminée — +{$reward_value} coin ajouté.";
    $status_type = "success";
} elseif (isset($_GET['error'])) {
    $err = $_GET['error'];
    if ($err === "limit_reached") {
        $status_msg = "❌ Tu as atteint la limite quotidienne de {$max_ads_per_day} pubs.";
        $status_type = "error";
    } elseif ($err === "invalid_token" || $err === "not_logged") {
        $status_msg = "⚠️ Action non autorisée. Réessaie depuis la page principale.";
        $status_type = "error";
    } else {
        $status_msg = "⚠️ Erreur : " . htmlspecialchars($err);
        $status_type = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Coins - ZyraHost</title>
<style>
:root{
  --bg:#0f0f12;
  --card:#121216;
  --muted:#9aa0a6;
  --accent:#5865F2;
  --accent-2:#6d7cff;
  --gold:#ffd700;
}
*{box-sizing:border-box}
body{
  margin:0;
  font-family:Inter, "Segoe UI", Roboto, Arial, sans-serif;
  background: linear-gradient(180deg, var(--bg) 0%, #070709 100%);
  color:#e8eef6;
  -webkit-font-smoothing:antialiased;
}
.container{
  max-width:980px;
  margin:36px auto;
  padding:20px;
}
.header{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:12px;
  margin-bottom:18px;
}
.brand{
  display:flex;
  gap:12px;
  align-items:center;
}
.logo{
  width:56px;
  height:56px;
  border-radius:12px;
  background:linear-gradient(135deg,var(--accent),var(--accent-2));
  display:flex;
  align-items:center;
  justify-content:center;
  font-weight:700;
  color:white;
  font-size:20px;
  box-shadow:0 6px 18px rgba(88,101,242,0.14);
}
.h1{
  font-size:20px;
  margin:0;
}
.sub{
  color:var(--muted);
  font-size:13px;
}
.grid{
  display:grid;
  grid-template-columns: 1fr 380px;
  gap:20px;
}
.card{
  background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
  border:1px solid rgba(255,255,255,0.03);
  padding:20px;
  border-radius:14px;
  box-shadow: 0 6px 22px rgba(2,6,23,0.5);
}
.profile {
  display:flex;
  gap:14px;
  align-items:center;
}
.avatar{
  width:64px;height:64px;border-radius:12px;background:#111;
  display:flex;align-items:center;justify-content:center;font-weight:700;color:#fff;
  font-size:20px;
  border:1px solid rgba(255,255,255,0.02);
}
.coins {
  font-size:28px;
  font-weight:700;
  color:var(--gold);
}
.progress-wrap{
  margin-top:18px;
}
.progress-line{
  height:12px;
  background:rgba(255,255,255,0.04);
  border-radius:999px;
  overflow:hidden;
  position:relative;
}
.progress-fill{
  height:100%;
  background: linear-gradient(90deg,var(--accent),var(--accent-2));
  width:0%;
  transition:width .6s ease;
}
.progress-meta{
  display:flex;justify-content:space-between;margin-top:10px;color:var(--muted);font-size:13px;
}
.controls{
  display:flex;flex-direction:column;gap:12px;
  align-items:center;
}
.btn{
  background:var(--accent);
  border:none;
  color:white;
  padding:12px 18px;
  border-radius:12px;
  font-weight:700;
  cursor:pointer;
  min-width:220px;
  transition:transform .12s ease, box-shadow .12s;
  box-shadow: 0 8px 20px rgba(88,101,242,0.12);
}
.btn:active{transform:translateY(1px)}
.btn:disabled{
  opacity:.5;
  cursor:not-allowed;
  transform:none;
  box-shadow:none;
}
.small{
  font-size:13px;color:var(--muted);
}
.status{
  padding:10px 14px;border-radius:10px;font-size:14px;margin-bottom:12px;
}
.status.success{background:rgba(16,185,129,0.08);color:#8ef0b8;border:1px solid rgba(16,185,129,0.08)}
.status.error{background:rgba(255,99,71,0.06);color:#ffb3aa;border:1px solid rgba(255,99,71,0.04)}
.footer{
  margin-top:18px;color:var(--muted);font-size:13px;text-align:center;
}
@media(max-width:900px){
  .grid{grid-template-columns:1fr; padding:0 10px}
  .container{padding:12px}
}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="brand">
      <div class="logo">Z</div>
      <div>
        <div class="h1">ZyraHost — Centre des Coins</div>
        <div class="sub">Gagne des coins en regardant des pubs (sécurisé)</div>
      </div>
    </div>
    <div class="sub">Bonjour, <?php echo $username; ?></div>
  </div>

  <div class="grid">
    <!-- LEFT: main -->
    <div class="card">
      <div class="profile">
        <div class="avatar"><?php echo strtoupper(substr($username,0,1)); ?></div>
        <div>
          <div style="font-size:14px;color:var(--muted)">Solde actuel</div>
          <div class="coins"><?php echo number_format($coins); ?> <span style="font-size:14px;color:var(--muted)">coins</span></div>
        </div>
      </div>

      <?php if ($status_msg): ?>
        <div style="margin-top:16px" class="status <?php echo ($status_type === 'success') ? 'success' : 'error'; ?>">
          <?php echo htmlspecialchars($status_msg); ?>
        </div>
      <?php endif; ?>

      <div class="progress-wrap">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div style="font-weight:700">Progression aujourd'hui</div>
          <div class="small"><?php echo $ads_today; ?> / <?php echo $max_ads_per_day; ?></div>
        </div>

        <div class="progress-line" aria-hidden="true">
          <div id="progressFill" class="progress-fill" style="width:<?php echo $progress_percent; ?>%"></div>
        </div>

        <div class="progress-meta">
          <div class="small">Récompense : +<?php echo $reward_value; ?> coin par pub</div>
          <div class="small"><?php echo $remaining; ?> restantes aujourd'hui</div>
        </div>
      </div>

      <div style="margin-top:20px;">
        <div style="color:var(--muted);font-size:13px">Règles :</div>
        <ul style="color:var(--muted);margin:8px 0 0 18px">
          <li>1 pub vue = <?php echo $reward_value; ?> coin</li>
          <li>Maximum <?php echo $max_ads_per_day; ?> pubs par jour</li>
          <li>Tentative de fraude entraîne blocage</li>
        </ul>
      </div>

      <div class="footer">Besoin d'aide ? Contacte le support via le panel.</div>
    </div>

    <!-- RIGHT: controls -->
    <div class="card">
      <div style="text-align:center">
        <div style="font-weight:700;font-size:18px">Méthodes de gain</div>
        <div class="small" style="margin-top:8px;color:var(--muted)">Choisis ta méthode pour gagner des coins</div>

        <div style="margin-top:16px" class="controls">
          <!-- Méthode 1: Publicités -->
          <div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,0.05)">
            <div style="font-weight:600;margin-bottom:8px">🎥 Publicités</div>
            <button id="watchBtn" class="btn" <?php echo $btn_disabled; ?>>
              Regarder une pub (+<?php echo $reward_value; ?> coin)
            </button>
            <div style="margin-top:8px" class="small">
              <strong><?php echo $remaining; ?></strong> pubs restantes aujourd'hui
            </div>
          </div>

          <!-- Méthode 2: Statut Discord -->
          <div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,0.05)">
            <div style="font-weight:600;margin-bottom:8px">💬 Statut Discord</div>
            <a href="/coins/coins--discord.php" style="text-decoration:none">
              <button class="btn" style="background:linear-gradient(135deg,#5865F2,#7289DA)">
                Vérifier mon statut (+5 coins)
              </button>
            </a>
            <div style="margin-top:8px" class="small">
              Une fois par jour • "zyrahost.fr | host bots gratuit"
            </div>
          </div>

          <!-- Méthode 3: Connexion quotidienne -->
          <div style="margin-bottom:16px">
            <div style="font-weight:600;margin-bottom:8px">📅 Connexion quotidienne</div>
            <a href="/coins/coins--daily.php" style="text-decoration:none">
              <button class="btn" style="background:linear-gradient(135deg,#10b981,#059669)">
                Récompense quotidienne (+3 coins)
              </button>
            </a>
            <div style="margin-top:8px" class="small">
              Disponible une fois par jour
            </div>
          </div>

          <div style="width:100%;margin-top:14px;text-align:center;color:var(--muted);font-size:13px">
            <a href="/coins/coins.php" style="color:var(--muted);text-decoration:none">← Retour aux coins</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {

    const btn = document.getElementById("watchBtn");
    const dailyBtn = document.getElementById("dailyBtn");
    
    if (btn) {
        btn.addEventListener("click", async (e) => {
            e.preventDefault();

            const original = btn.innerText;
            btn.disabled = true;
            btn.innerText = "⏳ Chargement...";

            console.log("[DEBUG] → Envoi requête vers /api/coins.php");

            try {
                // Simuler une requête au serveur (simplifié)
                setTimeout(() => {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = '';
                    form.style.display = 'none';
                    
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'simulate_ad';
                    input.value = '1';
                    
                    form.appendChild(input);
                    document.body.appendChild(form);
                    form.submit();
                }, 1000);
                
                btn.innerText = "⏳ Traitement...";
                
            } catch (err) {
                console.error("[DEBUG] ERREUR :", err);
                alert("Erreur !");
                btn.disabled = false;
                btn.innerText = original;
            }

        });
    }

    // Gestion du bouton récompense quotidienne
    if (dailyBtn) {
        dailyBtn.addEventListener("click", async (e) => {
            e.preventDefault();
            window.location.href = "/coins/coins--daily.php";
        });
    }

});
</script>


</body>
</html>
