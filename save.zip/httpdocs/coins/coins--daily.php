<?php
/*
 daily-reward.php - Récompense de connexion quotidienne
 - Donne une récompense une fois par jour
 - Simple et rapide
*/

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /login.php");
    exit;
}

// Paramètres DB
$db_host = 'localhost:3306';
$db_name = 'mttljx_zyrahostf_db';
$db_user = 'sti_moi';
$db_pass = 'pj32~lH36';

$reward_value = 3; // coins pour connexion quotidienne

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8",
        $db_user,
        $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    die("Erreur de connexion à la base de données.");
}

$user_id = (int)$_SESSION['user_id'];

// Vérifier si l'utilisateur a déjà reçu la récompense aujourd'hui (simplifié avec session)
$session_key = 'coins_' . date('Y-m-d');
if (!isset($_SESSION[$session_key])) {
    $_SESSION[$session_key] = ['ads' => 0, 'discord' => 0, 'daily' => 0];
}
$already_rewarded = $_SESSION[$session_key]['daily'] > 0;

// Récupérer infos utilisateur
$stmt = $pdo->prepare("SELECT username, coins FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    session_destroy();
    header("Location: /login.php");
    exit;
}

$username = htmlspecialchars($user['username']);
$coins = (int)$user['coins'];

$message = "";
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['claim_reward'])) {
    if (!$already_rewarded) {
        // Donner la récompense (simplifié)
        $stmt = $pdo->prepare("UPDATE users SET coins = coins + ? WHERE id = ?");
        $stmt->execute([$reward_value, $user_id]);
        
        // Mettre à jour la session
        $_SESSION[$session_key]['daily'] = 1;
        
        $coins += $reward_value;
        $already_rewarded = true;
        $success = true;
        $message = "✅ Récompense quotidienne claim ! +{$reward_value} coins ajoutés.";
    } else {
        $message = "⏰ Tu as déjà claim ta récompense aujourd'hui. Reviens demain !";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Récompense Quotidienne - ZyraHost</title>
<style>
:root{
  --bg:#0f0f12;
  --card:#121216;
  --muted:#9aa0a6;
  --accent:#5865F2;
  --accent-2:#6d7cff;
  --gold:#ffd700;
  --success:#10b981;
}
*{box-sizing:border-box}
body{
  margin:0;
  font-family:Inter, "Segoe UI", Roboto, Arial, sans-serif;
  background: linear-gradient(180deg, var(--bg) 0%, #070709 100%);
  color:#e8eef6;
  -webkit-font-smoothing:antialiased;
}
.container{
  max-width:500px;
  margin:36px auto;
  padding:20px;
}
.card{
  background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
  border:1px solid rgba(255,255,255,0.03);
  padding:30px;
  border-radius:14px;
  box-shadow: 0 6px 22px rgba(2,6,23,0.5);
}
.header{
  text-align:center;
  margin-bottom:30px;
}
.logo{
  width:64px;
  height:64px;
  border-radius:12px;
  background:linear-gradient(135deg,var(--success),#059669);
  display:flex;
  align-items:center;
  justify-content:center;
  font-weight:700;
  color:white;
  font-size:24px;
  margin:0 auto 16px;
  box-shadow:0 6px 18px rgba(16,185,129,0.14);
}
h1{
  font-size:24px;
  margin:0;
  color:#fff;
}
.subtitle{
  color:var(--muted);
  font-size:14px;
  margin-top:8px;
}
.reward-display{
  text-align:center;
  margin:30px 0;
}
.reward-amount{
  font-size:48px;
  font-weight:700;
  color:var(--gold);
  margin:0;
}
.reward-label{
  color:var(--muted);
  font-size:16px;
  margin-top:8px;
}
.streak-info{
  background:rgba(255,255,255,0.02);
  padding:16px;
  border-radius:8px;
  margin-bottom:20px;
  text-align:center;
}
.streak-info h3{
  margin:0 0 8px 0;
  font-size:16px;
  color:var(--success);
}
.btn{
  width:100%;
  background:linear-gradient(135deg,var(--success),#059669);
  border:none;
  color:white;
  padding:14px 20px;
  border-radius:10px;
  font-weight:700;
  font-size:16px;
  cursor:pointer;
  transition:transform 0.12s ease, box-shadow 0.12s;
  box-shadow: 0 8px 20px rgba(16,185,129,0.12);
}
.btn:active{transform:translateY(1px)}
.btn:disabled{
  opacity:.5;
  cursor:not-allowed;
  transform:none;
  box-shadow:none;
}
.status{
  padding:12px 16px;
  border-radius:10px;
  font-size:14px;
  margin-bottom:20px;
  text-align:center;
}
.status.success{background:rgba(16,185,129,0.08);color:#8ef0b8;border:1px solid rgba(16,185,129,0.08)}
.status.error{background:rgba(255,99,71,0.06);color:#ffb3aa;border:1px solid rgba(255,99,71,0.04)}
.back-link{
  text-align:center;
  margin-top:20px;
}
.back-link a{
  color:var(--muted);
  text-decoration:none;
  font-size:13px;
}
.back-link a:hover{
  color:var(--accent);
}
</style>
</head>
<body>
<div class="container">
  <div class="card">
    <div class="header">
      <div class="logo">📅</div>
      <h1>Récompense Quotidienne</h1>
      <div class="subtitle">Gagne des coins en te connectant chaque jour</div>
    </div>

    <?php if ($message): ?>
      <div class="status <?php echo $success ? 'success' : 'error'; ?>">
        <?php echo htmlspecialchars($message); ?>
      </div>
    <?php endif; ?>

    <div class="reward-display">
      <div class="reward-amount">+<?php echo $reward_value; ?></div>
      <div class="reward-label">coins par jour</div>
    </div>

    <div class="streak-info">
      <h3>🔥 Série de connexions</h3>
      <div style="color:var(--muted);font-size:14px">
        Connecte-toi chaque jour pour maintenir ta série et débloquer des bonus !
      </div>
    </div>

    <form method="POST">
      <button type="submit" name="claim_reward" class="btn" 
              <?php echo $already_rewarded ? 'disabled' : ''; ?>>
        <?php echo $already_rewarded ? '⏰ Récompense déjà claim aujourd\'hui' : '🎁 Claim ma récompense quotidienne'; ?>
      </button>
    </form>

    <div class="back-link">
      <a href="/coins/coins.php">← Retour aux coins</a>
    </div>
  </div>
</div>
</body>
</html>
