<?php
/*
 install.php - Page d'installation des tables du système de coins
 - Crée automatiquement toutes les tables nécessaires
 - Ajoute les colonnes manquantes
 - Affiche un rapport d'installation
*/

session_start();

// Vérifier si l'utilisateur est admin (à adapter selon votre système)
$isAdmin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';

if (!$isAdmin) {
    // Pour le développement, on permet l'accès sans être admin
    // En production, décommentez les lignes suivantes :
    // header("HTTP/1.0 403 Forbidden");
    // exit("Accès réservé à l'administrateur");
}

// Paramètres DB
$db_host = 'localhost:3306';
$db_name = 'mttljx_zyrahostf_db';
$db_user = 'sti_moi';
$db_pass = 'pj32~lH36';

$messages = [];
$errors = [];

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8",
        $db_user,
        $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    $errors[] = "Erreur de connexion à la base de données : " . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['install'])) {
    // Créer les tables une par une avec gestion d'erreurs
    
    // Table ad_logs
    try {
        $sql = "CREATE TABLE IF NOT EXISTS ad_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            ad_provider VARCHAR(50) DEFAULT NULL,
            ad_revenue DECIMAL(10,2) DEFAULT 0.00,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (user_id, created_at)
        )";
        $pdo->exec($sql);
        $messages[] = "✅ Table ad_logs créée avec succès";
    } catch (Exception $e) {
        $errors[] = "❌ Erreur création table ad_logs : " . $e->getMessage();
    }
    
    // Table discord_status_rewards
    try {
        $sql = "CREATE TABLE IF NOT EXISTS discord_status_rewards (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            discord_user_id VARCHAR(50) NOT NULL,
            reward_amount INT NOT NULL,
            verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (user_id, created_at)
        )";
        $pdo->exec($sql);
        $messages[] = "✅ Table discord_status_rewards créée avec succès";
    } catch (Exception $e) {
        $errors[] = "❌ Erreur création table discord_status_rewards : " . $e->getMessage();
    }
    
    // Table daily_rewards
    try {
        $sql = "CREATE TABLE IF NOT EXISTS daily_rewards (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            reward_amount INT NOT NULL,
            streak_days INT DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (user_id, created_at)
        )";
        $pdo->exec($sql);
        $messages[] = "✅ Table daily_rewards créée avec succès";
    } catch (Exception $e) {
        $errors[] = "❌ Erreur création table daily_rewards : " . $e->getMessage();
    }
    
    // Table premium_purchases
    try {
        $sql = "CREATE TABLE IF NOT EXISTS premium_purchases (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            duration VARCHAR(20) NOT NULL,
            cost INT NOT NULL,
            old_expiry TIMESTAMP NULL,
            new_expiry TIMESTAMP NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (user_id)
        )";
        $pdo->exec($sql);
        $messages[] = "✅ Table premium_purchases créée avec succès";
    } catch (Exception $e) {
        $errors[] = "❌ Erreur création table premium_purchases : " . $e->getMessage();
    }
    
    // Table coin_purchases
    try {
        $sql = "CREATE TABLE IF NOT EXISTS coin_purchases (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            bundle_id VARCHAR(20) NOT NULL,
            coins_received INT NOT NULL,
            price_paid VARCHAR(20) NOT NULL,
            payment_method VARCHAR(20) DEFAULT 'unknown',
            transaction_id VARCHAR(100) DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (user_id)
        )";
        $pdo->exec($sql);
        $messages[] = "✅ Table coin_purchases créée avec succès";
    } catch (Exception $e) {
        $errors[] = "❌ Erreur création table coin_purchases : " . $e->getMessage();
    }
    
    // Table referral_rewards
    try {
        $sql = "CREATE TABLE IF NOT EXISTS referral_rewards (
            id INT AUTO_INCREMENT PRIMARY KEY,
            referrer_id INT NOT NULL,
            referred_id INT NOT NULL,
            amount INT NOT NULL,
            reason VARCHAR(50) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (referrer_id, referred_id)
        )";
        $pdo->exec($sql);
        $messages[] = "✅ Table referral_rewards créée avec succès";
    } catch (Exception $e) {
        $errors[] = "❌ Erreur création table referral_rewards : " . $e->getMessage();
    }
    
    // Ajouter les colonnes manquantes à la table users
    try {
        $sql = "ALTER TABLE users 
        ADD COLUMN IF NOT EXISTS referral_code VARCHAR(8) UNIQUE,
        ADD COLUMN IF NOT EXISTS referred_by INT,
        ADD COLUMN IF NOT EXISTS premium_until TIMESTAMP NULL";
        $pdo->exec($sql);
        $messages[] = "✅ Colonnes ajoutées à la table users";
    } catch (Exception $e) {
        $errors[] = "❌ Erreur ajout colonnes users : " . $e->getMessage();
    }
    
    // Ajouter l'index pour referred_by
    try {
        $sql = "ALTER TABLE users ADD INDEX IF NOT EXISTS referred_by (referred_by)";
        $pdo->exec($sql);
        $messages[] = "✅ Index referred_by ajouté";
    } catch (Exception $e) {
        $errors[] = "❌ Erreur ajout index : " . $e->getMessage();
    }
    
    // Mettre à jour les codes de parrainage
    try {
        $sql = "UPDATE users SET referral_code = UPPER(SUBSTRING(MD5(CONCAT(id, username, NOW())), 1, 8)) 
        WHERE referral_code IS NULL OR referral_code = ''";
        $pdo->exec($sql);
        $messages[] = "✅ Codes de parrainage générés";
    } catch (Exception $e) {
        $errors[] = "❌ Erreur génération codes : " . $e->getMessage();
    }
}

// Vérifier l'état actuel des tables
$tables = [];
if ($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = ?");
        $stmt->execute([$db_name]);
        $allTables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $requiredTables = ['ad_logs', 'discord_status_rewards', 'daily_rewards', 'premium_purchases', 'coin_purchases', 'referral_rewards'];
        foreach ($requiredTables as $table) {
            $tables[$table] = in_array($table, $allTables);
        }
    } catch (Exception $e) {
        $errors[] = "Erreur vérification tables : " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Installation Système de Coins - ZyraHost</title>
<style>
:root{
  --bg:#0f0f12;
  --card:#121216;
  --muted:#9aa0a6;
  --accent:#5865F2;
  --success:#10b981;
  --error:#ef4444;
}
*{box-sizing:border-box}
body{
  margin:0;
  font-family:Inter, "Segoe UI", Roboto, Arial, sans-serif;
  background: linear-gradient(180deg, var(--bg) 0%, #070709 100%);
  color:#e8eef6;
  -webkit-font-smoothing:antialiased;
  min-height:100vh;
}
.container{
  max-width:800px;
  margin:0 auto;
  padding:40px 20px;
}
.header{
  text-align:center;
  margin-bottom:40px;
}
.logo{
  width:64px;
  height:64px;
  border-radius:16px;
  background:linear-gradient(135deg,var(--accent),#7289DA);
  display:flex;
  align-items:center;
  justify-content:center;
  font-weight:700;
  color:white;
  font-size:24px;
  margin:0 auto 20px;
}
h1{
  font-size:28px;
  margin:0;
  color:#fff;
}
.subtitle{
  color:var(--muted);
  font-size:16px;
  margin-top:12px;
}
.card{
  background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
  border:1px solid rgba(255,255,255,0.03);
  padding:30px;
  border-radius:16px;
  margin-bottom:20px;
}
.status-grid{
  display:grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap:16px;
  margin-bottom:30px;
}
.status-item{
  display:flex;
  align-items:center;
  gap:12px;
  padding:16px;
  background:rgba(255,255,255,0.02);
  border-radius:12px;
}
.status-icon{
  width:24px;
  height:24px;
  border-radius:50%;
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:14px;
}
.status-icon.ok{
  background:var(--success);
  color:white;
}
.status-icon.ko{
  background:var(--error);
  color:white;
}
.status-text{
  flex:1;
  font-weight:600;
}
.messages{
  margin-bottom:20px;
}
.message{
  padding:12px 16px;
  border-radius:8px;
  margin-bottom:8px;
  font-size:14px;
}
.message.success{
  background:rgba(16,185,129,0.1);
  color:#10b981;
  border:1px solid rgba(16,185,129,0.2);
}
.message.error{
  background:rgba(239,68,68,0.1);
  color:#ef4444;
  border:1px solid rgba(239,68,68,0.2);
}
.install-btn{
  background:var(--accent);
  border:none;
  color:white;
  padding:14px 28px;
  border-radius:10px;
  font-weight:700;
  font-size:16px;
  cursor:pointer;
  transition:background 0.2s ease;
  width:100%;
}
.install-btn:hover{
  background:#7289DA;
}
.back-link{
  text-align:center;
  margin-top:30px;
}
.back-link a{
  color:var(--muted);
  text-decoration:none;
  font-size:14px;
}
.back-link a:hover{
  color:var(--accent);
}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="logo">🔧</div>
    <h1>Installation Système de Coins</h1>
    <div class="subtitle">Configuration des tables et colonnes nécessaires</div>
  </div>

  <div class="card">
    <h3 style="margin:0 0 20px 0">État des tables</h3>
    <div class="status-grid">
      <?php foreach ($tables as $table => $exists): ?>
      <div class="status-item">
        <div class="status-icon <?php echo $exists ? 'ok' : 'ko'; ?>">
          <?php echo $exists ? '✓' : '✗'; ?>
        </div>
        <div class="status-text"><?php echo htmlspecialchars($table); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <?php if (!empty($messages) || !empty($errors)): ?>
  <div class="card">
    <h3 style="margin:0 0 20px 0">Rapport d'installation</h3>
    <div class="messages">
      <?php foreach ($messages as $message): ?>
        <div class="message success"><?php echo htmlspecialchars($message); ?></div>
      <?php endforeach; ?>
      <?php foreach ($errors as $error): ?>
        <div class="message error"><?php echo htmlspecialchars($error); ?></div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <form method="POST">
    <button type="submit" name="install" class="install-btn">
      🚀 Lancer l'installation
    </button>
  </form>

  <div class="back-link">
    <a href="/coins/coins.php">← Retour aux coins</a>
  </div>
</div>
</body>
</html>
