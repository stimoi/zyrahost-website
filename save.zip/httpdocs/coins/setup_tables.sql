-- Script de création des tables pour le système de coins ZyraHost
-- Exécuter ce script dans phpMyAdmin ou directement en MySQL

-- Table pour les logs de publicités
CREATE TABLE IF NOT EXISTS ad_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    ad_provider VARCHAR(50) DEFAULT NULL,
    ad_revenue DECIMAL(10,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (user_id, created_at)
);

-- Table pour les récompenses de statut Discord
CREATE TABLE IF NOT EXISTS discord_status_rewards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    discord_user_id VARCHAR(50) NOT NULL,
    reward_amount INT NOT NULL,
    verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (user_id, created_at)
);

-- Table pour les récompenses quotidiennes
CREATE TABLE IF NOT EXISTS daily_rewards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    reward_amount INT NOT NULL,
    streak_days INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (user_id, created_at)
);

-- Table pour les achats premium
CREATE TABLE IF NOT EXISTS premium_purchases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    duration VARCHAR(20) NOT NULL,
    cost INT NOT NULL,
    old_expiry TIMESTAMP NULL,
    new_expiry TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (user_id)
);

-- Table pour les achats de coins
CREATE TABLE IF NOT EXISTS coin_purchases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    bundle_id VARCHAR(20) NOT NULL,
    coins_received INT NOT NULL,
    price_paid VARCHAR(20) NOT NULL,
    payment_method VARCHAR(20) DEFAULT 'unknown',
    transaction_id VARCHAR(100) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (user_id)
);

-- Table pour les récompenses de parrainage
CREATE TABLE IF NOT EXISTS referral_rewards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    referrer_id INT NOT NULL,
    referred_id INT NOT NULL,
    amount INT NOT NULL,
    reason VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (referrer_id, referred_id)
);

-- Ajouter les colonnes manquantes à la table users si elles n'existent pas
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS referral_code VARCHAR(8) UNIQUE,
ADD COLUMN IF NOT EXISTS referred_by INT,
ADD COLUMN IF NOT EXISTS premium_until TIMESTAMP NULL;

-- Ajouter un index pour referred_by
ALTER TABLE users ADD INDEX IF NOT EXISTS referred_by (referred_by);

-- Insérer quelques données de test si la table users est vide
INSERT IGNORE INTO users (id, username, email, password, coins, created_at) VALUES 
(1, 'admin', 'admin@zyrahost.fr', '$2y$10$dummy_hash', 1000, NOW()),
(2, 'testuser', 'test@zyrahost.fr', '$2y$10$dummy_hash', 50, NOW());

-- Mettre à jour les codes de parrainage pour les utilisateurs existants
UPDATE users SET referral_code = UPPER(SUBSTRING(MD5(CONCAT(id, username, NOW())), 1, 8)) 
WHERE referral_code IS NULL OR referral_code = '';

-- Afficher un résumé des tables créées
SELECT 
    TABLE_NAME as 'Table',
    TABLE_ROWS as 'Lignes (estimé)'
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME IN ('ad_logs', 'discord_status_rewards', 'daily_rewards', 'premium_purchases', 'coin_purchases', 'referral_rewards', 'users')
ORDER BY TABLE_NAME;
