# 📖 Référence API

> **Note :** L'API REST de Nexus Bot est actuellement en développement et sera disponible dans la v2.0.

## 🚀 Vue d'Ensemble

L'API Nexus Bot permettra d'interagir avec votre bot via des requêtes HTTP, idéal pour :
- Applications web externes
- Intégrations avec d'autres services
- Tableaux de bord personnalisés
- Automatisations avancées

## 🔐 Authentification

Toutes les requêtes API nécessiteront un token d'authentification :

```http
Authorization: Bearer VOTRE_TOKEN_API
```

## 📡 Endpoints Prévus

### Statistiques du Bot
```http
GET /api/v1/stats
```

**Réponse :**
```json
{
  "servers": 42,
  "users": 1250,
  "commands_today": 3420,
  "uptime": "5d 12h 30m",
  "version": "1.0.0"
}
```

### Informations Utilisateur
```http
GET /api/v1/users/{user_id}
```

**Réponse :**
```json
{
  "id": "123456789",
  "username": "Utilisateur",
  "balance": 1500,
  "level": 5,
  "xp": 2500,
  "commands_used": 142
}
```

### Exécuter une Commande
```http
POST /api/v1/commands
```

**Corps de la requête :**
```json
{
  "command": "balance",
  "user_id": "123456789",
  "guild_id": "987654321"
}
```

### Configuration du Serveur
```http
GET /api/v1/guilds/{guild_id}/config
PUT /api/v1/guilds/{guild_id}/config
```

## 🛠️ Exemples d'Utilisation

### Python
```python
import requests

headers = {
    "Authorization": "Bearer VOTRE_TOKEN_API"
}

# Obtenir les statistiques
response = requests.get("http://localhost:8080/api/v1/stats", headers=headers)
stats = response.json()
print(f"Serveurs: {stats['servers']}")
```

### JavaScript
```javascript
const headers = {
    "Authorization": "Bearer VOTRE_TOKEN_API"
};

fetch("http://localhost:8080/api/v1/stats", { headers })
    .then(response => response.json())
    .then(stats => {
        console.log(`Serveurs: ${stats.servers}`);
    });
```

### cURL
```bash
curl -H "Authorization: Bearer VOTRE_TOKEN_API" \
     http://localhost:8080/api/v1/stats
```

## 📊 Webhooks

Les webhooks permettront de recevoir des événements en temps réel :

### Événements Disponibles
- `user_join` - Un utilisateur rejoint un serveur
- `command_used` - Une commande est exécutée
- `economy_transaction` - Transaction économique
- `music_played` - Musique jouée

### Configuration Webhook
```http
POST /api/v1/webhooks
```

**Corps de la requête :**
```json
{
  "url": "https://votre-domaine.com/webhook",
  "events": ["command_used", "economy_transaction"],
  "secret": "votre_secret_webhook"
}
```

## 🔒 Limitations et Sécurité

### Rate Limiting
- 100 requêtes/minute par IP
- 1000 requêtes/heure par token

### Permissions
- Les tokens API ont des permissions spécifiques
- Possibilité de créer des tokens en lecture seule

### Sécurité
- HTTPS obligatoire en production
- Validation des entrées
- Logs d'audit complets

## 🚧 Statut de Développement

| Endpoint | Statut | Version |
|----------|--------|---------|
| `/api/v1/stats` | 🔄 En développement | v2.0 |
| `/api/v1/users` | 🔄 En développement | v2.0 |
| `/api/v1/commands` | 🔄 En développement | v2.0 |
| `/api/v1/guilds` | 🔄 En développement | v2.0 |
| Webhooks | 📋 Planifié | v2.1 |

## 📝 Notes de Version

### v2.0 (Prévu)
- API REST complète
- Authentification par token
- Rate limiting
- Documentation Swagger

### v2.1 (Prévu)
- Webhooks en temps réel
- API GraphQL
- SDK officiels

## 🤝 Contribuer à l'API

Vous voulez aider au développement de l'API ?
1. Consultez le [guide de développement](index.html#development)
2. Rejoignez notre serveur Discord
3. Ouvrez une issue sur GitHub

---

**Besoin d'aide ?** Contactez-nous sur [Discord](https://discord.gg/your-support) ou via [GitHub Issues](https://github.com/stimoi/nexus/issues).
