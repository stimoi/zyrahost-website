# 💡 Exemples et Cas d'Usage

Découvrez comment utiliser Nexus Bot dans différents scénarios avec des exemples pratiques.

## 🎮 Serveur de Gaming

### Configuration Rapide
```yaml
# config.yml
discord:
  prefix: "!"
  status: "🎮 En gaming"

economy:
  daily_min: 50
  daily_max: 100
  starting_balance: 500

music:
  default_volume: 70
  auto_leave: false
```

### Commandes Utiles
- `!daily` - Récompenses quotidiennes pour les joueurs actifs
- `!slot 100` - Machine à sous pour gagner des crédits
- `!musique lofi` - Musique d'ambiance pour gaming
- `!giveaway jeu` - Organiser des giveaways de jeux

### Exemple d'Automatisation
```python
# Récompenser les joueurs actifs
@bot.event
async def on_message(message):
    if message.channel.id == GAMING_CHANNEL_ID:
        # Ajouter de l'XP aux joueurs actifs
        add_experience(message.author.id, 1)
```

## �Serveur de Musique

### Configuration Musicale
```yaml
music:
  default_volume: 60
  quality: "high"
  max_song_length: 600
  auto_leave: true
  radio_stations:
    lofi: "https://stream-url.lofi"
    electronic: "https://stream-url.electronic"
```

### Playlists Automatiques
```python
# Créer des playlists thématiques
@bot.command()
async def playlist(ctx, theme):
    playlists = {
        "gaming": ["song1", "song2", "song3"],
        "chill": ["song4", "song5", "song6"],
        "energy": ["song7", "song8", "song9"]
    }
    
    if theme in playlists:
        for song in playlists[theme]:
            await play_song(ctx, song)
```

## 🏢 Serveur d'Entreprise

### Configuration Professionnelle
```yaml
discord:
  prefix: "/"
  status: "💼 Au travail"

moderation:
  log_channel: "admin-logs"
  welcome_channel: "accueil"
  auto_role: "employé"

economy:
  enabled: false  # Désactiver l'économie
```

### Tickets de Support
```python
# Système de tickets automatique
@bot.command()
async def ticket(ctx, sujet):
    category = discord.utils.get(ctx.guild.categories, name="Tickets")
    
    ticket_channel = await ctx.guild.create_text_channel(
        f"ticket-{ctx.author.name}",
        category=category
    )
    
    await ticket_channel.set_permissions(ctx.author, read_messages=True)
    await ticket_channel.send(f"Ticket créé par {ctx.author.mention}\nSujet: {sujet}")
```

## 🎨 Serveur Créatif

### Galerie d'Art avec IA
```python
@bot.command()
async def galerie(ctx):
    """Affiche une galerie d'images générées par l'IA"""
    images = get_generated_images()
    
    embed = discord.Embed(title="🎨 Galerie d'Art IA")
    
    for img in images[:5]:  # Limiter à 5 images
        embed.add_field(
            name=img["prompt"],
            value=f"Par {img['author']}",
            inline=False
        )
    
    await ctx.send(embed=embed)
```

### Concours Créatifs
```python
@bot.command()
async def concours(ctx, theme):
    """Lancer un concours créatif"""
    embed = discord.Embed(
        title="🎨 Nouveau Concours",
        description=f"Thème: {theme}\nUtilisez `/imagine {theme}` pour participer!"
    )
    embed.set_footer(text="Durée: 24h")
    
    await ctx.send(embed=embed)
```

## 📚 Serveur d'Étude

### Système de Quiz
```python
@bot.command()
async def quiz(ctx):
    """Lancer un quiz éducatif"""
    questions = [
        {
            "question": "Quelle est la capitale de la France ?",
            "options": ["Londres", "Berlin", "Paris", "Madrid"],
            "answer": 2
        }
    ]
    
    q = random.choice(questions)
    embed = discord.Embed(title="📚 Quiz Time")
    embed.add_field(name=q["question"], value="\n".join([f"{i+1}. {opt}" for i, opt in enumerate(q["options"])]))
    
    await ctx.send(embed=embed)
```

### Salons d'Étude Thématiques
```python
@bot.command()
async def etude(ctx, sujet):
    """Créer un salon d'étude temporaire"""
    category = discord.utils.get(ctx.guild.categories, name="Étude")
    
    study_channel = await ctx.guild.create_text_channel(
        f"étude-{sujet}",
        category=category
    )
    
    await study_channel.send(f"📚 Salon d'étude pour: {sujet}\nUtilisez `/ask` pour poser des questions!")
```

## 🛍️ Serveur Commercial

### Système de Boutique
```python
@bot.command()
async def boutique(ctx):
    """Afficher la boutique du serveur"""
    items = [
        {"name": "Rôle VIP", "price": 1000, "description": "Accès VIP pendant 30 jours"},
        {"name": "Couleur Personnalisée", "price": 500, "description": "Couleur de pseudo personnalisée"},
        {"name": "Badge Spécial", "price": 300, "description": "Badge unique sur votre profil"}
    ]
    
    embed = discord.Embed(title="🛍️ Boutique")
    
    for item in items:
        embed.add_field(
            name=f"{item['name']} - {item['price']} crédits",
            value=item['description'],
            inline=False
        )
    
    await ctx.send(embed=embed)
```

### Promotions Automatiques
```python
@tasks.loop(hours=24)
async def daily_promotion():
    """Promotion quotidienne automatique"""
    promotions = [
        "Double les récompenses /daily aujourd'hui !",
        "20% de réduction sur la boutique !",
        "Bonus de 500 crédits pour les 10 premières connexions !"
    ]
    
    promo = random.choice(promotions)
    channel = bot.get_channel(PROMOTION_CHANNEL_ID)
    await channel.send(f"🎉 Promotion du jour: {promo}")
```

## 🎯 Serveur de Communauté

### Événements Automatiques
```python
@tasks.loop(hours=6)
async def community_event():
    """Organiser des événements communautaires"""
    events = [
        "Concours de memes",
        "Karaoké musical",
        "Session de jeux ensemble",
        "Quiz général",
        "Partage de talents"
    ]
    
    event = random.choice(events)
    channel = bot.get_channel(EVENTS_CHANNEL_ID)
    
    embed = discord.Embed(
        title="🎉 Événement Communautaire",
        description=f"Nouvel événement: {event}\nRéagissez avec ✅ pour participer!"
    )
    
    message = await channel.send(embed=embed)
    await message.add_reaction("✅")
```

### Système de Rôles par Niveau
```python
@bot.event
async def on_level_up(user, new_level):
    """Attribuer des rôles selon le niveau"""
    guild = user.guild
    
    roles_by_level = {
        5: "Membre Actif",
        10: "Membre Dévoué",
        25: "Membre Vétéran",
        50: "Membre Légendaire"
    }
    
    if new_level in roles_by_level:
        role = discord.utils.get(guild.roles, name=roles_by_level[new_level])
        if role:
            await user.add_roles(role)
            
            embed = discord.Embed(
                title="🎉 Niveau Supérieur !",
                description=f"Félicitations {user.mention} ! Vous avez atteint le niveau {new_level} et obtenu le rôle {role.mention} !"
            )
            
            await guild.system_channel.send(embed=embed)
```

## 🔧 Scripts Utiles

### Backup Automatique
```python
@tasks.loop(hours=24)
async def backup_data():
    """Sauvegarder les données du bot"""
    import shutil
    from datetime import datetime
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = f"backup_{timestamp}.json"
    
    shutil.copy2("data.json", backup_file)
    print(f"Backup créé: {backup_file}")
```

### Statistiques Quotidiennes
```python
@tasks.loop(hours=24)
async def daily_stats():
    """Envoyer les statistiques quotidiennes"""
    stats = calculate_daily_stats()
    
    embed = discord.Embed(title="📊 Statistiques Quotidiennes")
    embed.add_field(name="Nouveaux membres", value=stats["new_members"])
    embed.add_field(name="Messages envoyés", value=stats["messages"])
    embed.add_field(name="Commandes utilisées", value=stats["commands"])
    
    channel = bot.get_channel(STATS_CHANNEL_ID)
    await channel.send(embed=embed)
```

---

**Besoin d'aide pour votre cas d'usage spécifique ?** Rejoignez notre [serveur Discord](https://discord.gg/your-support) !
