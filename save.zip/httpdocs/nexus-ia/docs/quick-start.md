# 🚀 Guide de Démarrage Rapide

Ce guide vous aidera à installer et configurer Nexus Bot en moins de 10 minutes.

## ⚡ Installation Express

### 1. Prérequis (2 minutes)
- Python 3.8+ installé
- Un compte Discord
- Un token d'application Discord

### 2. Cloner et Installer (3 minutes)
```bash
git clone https://github.com/stimoi/nexus.git
cd nexus
pip install -r requirements.txt
```

### 3. Configuration (3 minutes)
```bash
cp config.yml.example config.yml
# Éditez config.yml avec vos clés API
```

### 4. Démarrer (1 minute)
```bash
python bot.py
```

## 🔧 Configuration Minimale

Ouvrez `config.yml` et modifiez ces lignes :

```yaml
discord:
  token: "VOTRE_TOKEN_DISCORD"

openai:
  api_key: "VOTRE_CLE_OPENAI"
```

## 📋 Obtenir les Tokens

### Token Discord
1. Allez sur le [Portail Développeur Discord](https://discord.com/developers/applications)
2. Créez une nouvelle application
3. Allez dans "Bot" → "Copy Token"

### Clé OpenAI
1. Allez sur [platform.openai.com](https://platform.openai.com/)
2. Créez un compte
3. Allez dans API Keys → "Create new secret key"

## ✅ Vérification

Une fois le bot démarré, vous devriez voir :
```
🤖 Nexus Bot est en ligne !
📊 Connecté à X serveurs
👥 X utilisateurs
```

## 🎯 Premières Commandes

Testez votre bot avec ces commandes :
- `/ask Bonjour` - Tester l'IA
- `/daily` - Récompense journalière
- `/help` - Voir toutes les commandes

## 🆘 Problèmes ?

Si vous rencontrez des problèmes :
1. Vérifiez que le token est correct
2. Assurez-vous que Python 3.8+ est utilisé
3. Consultez le [guide de dépannage complet](index.html#troubleshooting)

## 🎉 Félicitations !

Votre Nexus Bot est maintenant opérationnel ! 

**Prochaines étapes :**
- [Documentation complète](index.html)
- [Personnalisation avancée](index.html#configuration)
- [Rejoindre la communauté](https://discord.gg/your-support)
