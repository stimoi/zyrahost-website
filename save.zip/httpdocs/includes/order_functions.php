<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/offers.php';

function createOrder($userId, $offerId, $billingCycle = 'monthly') {
    global $pdo, $offers;
    
    // Vérifier si l'offre existe
    if (!isset($offers[$offerId])) {
        return ['success' => false, 'message' => 'Offre non valide'];
    }
    
    $offer = $offers[$offerId];
    
    try {
        $pdo->beginTransaction();
        
        // Calculer le prix en fonction de la durée
        $price = $offer['price'];
        if ($billingCycle === 'yearly') {
            $price = $price * 10; // 2 mois gratuits pour un an
        }
        
        // Créer la commande
        $stmt = $pdo->prepare("
            INSERT INTO orders (user_id, offer_id, status, amount, billing_cycle, created_at) 
            VALUES (:user_id, :offer_id, 'pending', :amount, :billing_cycle, NOW())
        ");
        
        $stmt->execute([
            ':user_id' => $userId,
            ':offer_id' => $offerId,
            ':amount' => $price,
            ':billing_cycle' => $billingCycle
        ]);
        
        $orderId = $pdo->lastInsertId();
        $pdo->commit();
        
        return [
            'success' => true,
            'order_id' => $orderId,
            'amount' => $price,
            'offer' => $offer
        ];
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Erreur lors de la création de la commande: " . $e->getMessage());
        return ['success' => false, 'message' => 'Erreur lors de la création de la commande'];
    }
}

function getUserOrders($userId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT o.*, p.name as product_name, p.description as product_description 
        FROM orders o
        LEFT JOIN products p ON o.product_id = p.id
        WHERE o.user_id = :user_id
        ORDER BY o.created_at DESC
    ");
    
    $stmt->execute([':user_id' => $userId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function processPayment($orderId, $paymentMethod = 'stripe') {
    // Intégration avec un système de paiement (à implémenter)
    // Pour l'instant, on simule un paiement réussi
    return ['success' => true, 'message' => 'Paiement réussi'];
}

function provisionVPS($orderId) {
    // Logique de provisionnement du VPS (à implémenter avec l'API de virtualisation)
    // Pour l'instant, on simule un provisionnement réussi
    return ['success' => true, 'message' => 'VPS provisionné avec succès'];
}
?>
